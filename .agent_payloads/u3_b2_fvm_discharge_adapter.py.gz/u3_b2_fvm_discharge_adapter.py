"""Production-side U3 B2 single-phase FVM discharge-face adapter.

The adapter implements the locked U3 B2 mapping without importing the U3 B2
independent Reference or sharing any B2-specific Reference helper.  It uses the
accepted U3 B1 adapter only as the upstream single-phase discharge authority.

Positive transfer is outward through the right boundary.  This remains a
verification-only implementation: finite-pipe acceptance, physical validation,
design use, two-phase critical discharge, and production activation are not
approved by this module.
"""

from __future__ import annotations

import copy
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, Protocol

import numpy as np

from . import u3_b1_critical_state_adapter as b1_adapter
from .eos import EOSModel
from .state import (
    IDX_MOM,
    IDX_RHO,
    IDX_RHOE,
    IDX_RHO_XV,
    N_VARS,
    PrimitiveState,
)

CONTRACT_SCHEMA_VERSION = "stage7_u3_b2_fvm_discharge_coupling_contract_v1"
B1_CONTRACT_SCHEMA_VERSION = "stage7_u3_b1_critical_state_contract_v1"

SUCCESS_CLOSED_WALL_MAPPING = "SUCCESS_CLOSED_WALL_MAPPING"
SUCCESS_ZERO_DROP_WALL_IDENTITY = "SUCCESS_ZERO_DROP_WALL_IDENTITY"
SUCCESS_UNCHOKED_FACE_MAPPING = "SUCCESS_UNCHOKED_FACE_MAPPING"
SUCCESS_CHOKED_FACE_MAPPING = "SUCCESS_CHOKED_FACE_MAPPING"
SUCCESS_ONE_STEP = "SUCCESS_ONE_STEP_CONSERVATIVE_UPDATE"
REVERSE_PRESSURE_OR_FLOW_NOT_SUPPORTED = (
    "REVERSE_PRESSURE_OR_FLOW_NOT_SUPPORTED"
)
NONFINITE_INPUT = "NONFINITE_INPUT"
ADJACENT_STATE_OUTSIDE_SINGLE_PHASE_SCOPE = (
    "ADJACENT_STATE_OUTSIDE_SINGLE_PHASE_SCOPE"
)
STAGNATION_RECONSTRUCTION_FAILURE = "STAGNATION_RECONSTRUCTION_FAILURE"
BOUNDARY_UPDATE_POSITIVITY_FAILURE = "BOUNDARY_UPDATE_POSITIVITY_FAILURE"
INVENTORY_ORIENTATION_CONTRACT_MISMATCH = (
    "INVENTORY_ORIENTATION_CONTRACT_MISMATCH"
)

_B1_SUCCESS_CLOSED = "SUCCESS_CLOSED"
_B1_SUCCESS_ZERO_DROP = "SUCCESS_ZERO_PRESSURE_DROP"
_B1_SUCCESS_UNCHOKED = "SUCCESS_UNCHOKED_SINGLE_PHASE_DISCHARGE"
_B1_SUCCESS_CHOKED = "SUCCESS_CHOKED_SINGLE_PHASE_DISCHARGE"
_B1_REVERSE_PRESSURE = "REVERSE_PRESSURE_NOT_SUPPORTED"
_B1_NONFINITE = "NONFINITE_INPUT"
_B1_OUTSIDE_SCOPE = "UPSTREAM_STATE_OUTSIDE_DECLARED_PHASE_SCOPE"

_REPO_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_B2_CONTRACT_PATH = (
    _REPO_ROOT
    / "docs/verification/stage7_u3_b2_fvm_discharge_coupling_contract_v1.json"
)
DEFAULT_B1_CONTRACT_PATH = (
    _REPO_ROOT / "docs/verification/stage7_u3_b1_critical_state_contract_v1.json"
)


class U3B2FaceGuardError(RuntimeError):
    """Raised before flux, budget, or state mutation when a B2 Guard fires."""

    def __init__(self, outcome: str, message: str) -> None:
        super().__init__(f"{outcome}: {message}")
        self.outcome = outcome
        self.message = message


@dataclass(frozen=True)
class AdjacentStaticState:
    pressure_pa: float
    temperature_K: float
    density_kg_m3: float
    internal_energy_J_kg: float
    enthalpy_J_kg: float
    entropy_J_kg_K: float
    sound_speed_m_s: float
    phase: str
    velocity_m_s: float


@dataclass(frozen=True)
class StagnationReconstruction:
    static: AdjacentStaticState
    stagnation_pressure_pa: float
    stagnation_temperature_K: float
    stagnation_enthalpy_J_kg: float
    stagnation_entropy_J_kg_K: float
    enthalpy_round_trip_residual_J_kg: float
    entropy_round_trip_residual_J_kg_K: float


@dataclass(frozen=True)
class U3B2FaceConfiguration:
    case_id: str
    state_id: str
    expected_face_outcome: str
    back_pressure_pa: float
    opening_fraction: float
    discharge_coefficient: float
    pipe_area_m2: float
    allowed_normalized_phases: tuple[str, ...]
    velocity_zero_tolerance_m_s: float
    stagnation_enthalpy_tolerance_J_kg: float
    stagnation_entropy_tolerance_J_kg_K: float
    mass_removal_fraction_limit: float
    energy_removal_fraction_limit: float
    maximum_halvings: int
    nominal_static_pressure_pa: float

    def __post_init__(self) -> None:
        numeric = (
            self.back_pressure_pa,
            self.opening_fraction,
            self.discharge_coefficient,
            self.pipe_area_m2,
            self.velocity_zero_tolerance_m_s,
            self.stagnation_enthalpy_tolerance_J_kg,
            self.stagnation_entropy_tolerance_J_kg_K,
            self.mass_removal_fraction_limit,
            self.energy_removal_fraction_limit,
            self.nominal_static_pressure_pa,
        )
        if not all(math.isfinite(value) for value in numeric):
            raise ValueError("B2 face configuration contains a nonfinite value")
        if not 0.0 <= self.opening_fraction <= 1.0:
            raise ValueError("opening_fraction must lie in [0, 1]")
        if self.discharge_coefficient <= 0.0:
            raise ValueError("discharge_coefficient must be positive")
        if self.pipe_area_m2 <= 0.0:
            raise ValueError("pipe_area_m2 must be positive")
        if self.velocity_zero_tolerance_m_s < 0.0:
            raise ValueError("velocity tolerance must be non-negative")
        if self.stagnation_enthalpy_tolerance_J_kg < 0.0:
            raise ValueError("enthalpy tolerance must be non-negative")
        if self.stagnation_entropy_tolerance_J_kg_K < 0.0:
            raise ValueError("entropy tolerance must be non-negative")
        if not 0.0 < self.mass_removal_fraction_limit <= 1.0:
            raise ValueError("mass removal limit must lie in (0, 1]")
        if not 0.0 < self.energy_removal_fraction_limit <= 1.0:
            raise ValueError("energy removal limit must lie in (0, 1]")
        if self.maximum_halvings < 0:
            raise ValueError("maximum_halvings must be non-negative")
        if not self.allowed_normalized_phases:
            raise ValueError("allowed_normalized_phases must not be empty")


@dataclass(frozen=True)
class U3B2FaceResult:
    case_id: str
    state_id: str
    formal_outcome: str
    formal_message: str
    raw_b1_formal_outcome: str
    raw_b1_message: str
    upstream_static_pressure_pa: float | None
    upstream_static_temperature_K: float | None
    upstream_density_kg_m3: float | None
    upstream_internal_energy_J_kg: float | None
    upstream_enthalpy_J_kg: float | None
    upstream_entropy_J_kg_K: float | None
    upstream_sound_speed_m_s: float | None
    upstream_phase: str | None
    adjacent_velocity_m_s: float | None
    stagnation_pressure_pa: float | None
    stagnation_temperature_K: float | None
    stagnation_enthalpy_J_kg: float | None
    stagnation_entropy_J_kg_K: float | None
    back_pressure_pa: float
    discharge_state_pressure_pa: float | None
    critical_pressure_pa: float | None
    opening_fraction: float
    discharge_coefficient: float
    pipe_area_m2: float
    open_area_m2: float
    closed_area_m2: float
    effective_velocity_m_s: float
    mass_transfer_outward_kg_s: float
    advective_momentum_rate_out_N: float
    open_static_pressure_force_out_N: float
    closed_static_pressure_force_out_N: float
    total_momentum_rate_out_N: float
    energy_transfer_outward_W: float
    F_rho_kg_m2_s: float
    F_rho_u_pa: float
    F_rho_E_W_m2: float
    F_rho_xv_kg_m2_s: float
    pressure_decomposition_residual_pa: float
    zero_drop_canonicalization_applied: bool

    @property
    def succeeded(self) -> bool:
        return self.formal_outcome.startswith("SUCCESS_")

    def flux_vector(self) -> np.ndarray:
        if not self.succeeded:
            raise U3B2FaceGuardError(self.formal_outcome, self.formal_message)
        return np.array(
            [
                self.F_rho_kg_m2_s,
                self.F_rho_u_pa,
                self.F_rho_E_W_m2,
                self.F_rho_xv_kg_m2_s,
            ],
            dtype=float,
        )


@dataclass(frozen=True)
class U3B2OneStepResult:
    formal_outcome: str
    accepted_dt_s: float
    halving_count: int
    cfl_dt_s: float
    mass_removal_dt_s: float
    energy_removal_dt_s: float
    U_before: tuple[float, float, float, float]
    left_flux: tuple[float, float, float, float]
    right_flux: tuple[float, float, float, float]
    U_after: tuple[float, float, float, float]
    normalized_balance_residual: float
    mass_inventory_residual_kg: float
    momentum_inventory_residual_kg_m_s: float
    energy_inventory_residual_J: float
    vapor_inventory_residual_kg: float


class AdjacentPropertyProvider(Protocol):
    version: str

    def reconstruct(self, conserved: np.ndarray) -> StagnationReconstruction: ...


class B1ResultLike(Protocol):
    formal_outcome: str
    formal_message: str
    evaluation_pressure_pa: float | None
    critical_pressure_pa: float | None
    effective_velocity_m_s: float
    mass_transfer_outward_kg_s: float
    momentum_stream_transfer_outward_N: float
    energy_transfer_outward_W: float


B1Evaluator = Callable[..., B1ResultLike]


def normalize_phase(value: str) -> str:
    return value.lower().replace("_", "").replace(" ", "")


class CoolPropAdjacentPropertyProvider:
    """Production-side Dmass/Umass and Hmass/Smass property path.

    The implementation uses ``AbstractState`` and is deliberately independent
    of the U3 B2 Reference's ``PropsSI``-based path.
    """

    def __init__(self) -> None:
        from CoolProp import (
            AbstractState,
            DmassUmass_INPUTS,
            HmassSmass_INPUTS,
            PQ_INPUTS,
            PT_INPUTS,
            __version__ as coolprop_version,
        )
        from CoolProp.CoolProp import PhaseSI

        self._static = AbstractState("HEOS", "CO2")
        self._stagnation = AbstractState("HEOS", "CO2")
        self._initializer = AbstractState("HEOS", "CO2")
        self._saturation = AbstractState("HEOS", "CO2")
        self._DmassUmass_INPUTS = DmassUmass_INPUTS
        self._HmassSmass_INPUTS = HmassSmass_INPUTS
        self._PQ_INPUTS = PQ_INPUTS
        self._PT_INPUTS = PT_INPUTS
        self._phase_si = PhaseSI
        self.version = str(coolprop_version)

    def conserved_from_pressure_temperature(
        self,
        pressure_pa: float,
        temperature_K: float,
        *,
        velocity_m_s: float = 0.0,
    ) -> np.ndarray:
        values = (pressure_pa, temperature_K, velocity_m_s)
        if not all(math.isfinite(value) for value in values):
            raise ValueError("initial state inputs must be finite")
        if pressure_pa <= 0.0 or temperature_K <= 0.0:
            raise ValueError("initial pressure and temperature must be positive")
        self._initializer.update(self._PT_INPUTS, pressure_pa, temperature_K)
        rho = float(self._initializer.rhomass())
        internal_energy = float(self._initializer.umass())
        if not math.isfinite(rho) or rho <= 0.0:
            raise ValueError("CoolProp initial density must be positive")
        if not math.isfinite(internal_energy) or internal_energy <= 0.0:
            raise ValueError("CoolProp initial internal energy must be positive")
        total_energy = internal_energy + 0.5 * velocity_m_s * velocity_m_s
        return np.array(
            [rho, rho * velocity_m_s, rho * total_energy, 0.0],
            dtype=float,
        )

    def conserved_from_pressure_subcooling(
        self,
        pressure_pa: float,
        subcooling_K: float,
        *,
        velocity_m_s: float = 0.0,
    ) -> np.ndarray:
        if not math.isfinite(subcooling_K):
            raise ValueError("subcooling must be finite")
        self._saturation.update(self._PQ_INPUTS, pressure_pa, 0.0)
        temperature = float(self._saturation.T()) - subcooling_K
        return self.conserved_from_pressure_temperature(
            pressure_pa,
            temperature,
            velocity_m_s=velocity_m_s,
        )

    def reconstruct(self, conserved: np.ndarray) -> StagnationReconstruction:
        values = np.asarray(conserved, dtype=float)
        if values.shape != (N_VARS,):
            raise ValueError(f"adjacent conserved state must have shape ({N_VARS},)")
        if not np.all(np.isfinite(values)):
            raise FloatingPointError("adjacent conserved state contains NaN or infinity")

        rho = float(values[IDX_RHO])
        if rho <= 0.0:
            raise ValueError("adjacent density must be positive")
        velocity = float(values[IDX_MOM] / rho)
        total_specific_energy = float(values[IDX_RHOE] / rho)
        internal_energy = total_specific_energy - 0.5 * velocity * velocity
        if not math.isfinite(internal_energy) or internal_energy <= 0.0:
            raise ValueError("adjacent internal energy must be positive and finite")

        self._static.update(self._DmassUmass_INPUTS, rho, internal_energy)
        pressure = float(self._static.p())
        temperature = float(self._static.T())
        enthalpy = float(self._static.hmass())
        entropy = float(self._static.smass())
        sound_speed = float(self._static.speed_sound())
        phase = str(
            self._phase_si(
                "Dmass",
                rho,
                "Umass",
                internal_energy,
                "CO2",
            )
        )

        h0 = enthalpy + 0.5 * velocity * velocity
        s0 = entropy
        self._stagnation.update(self._HmassSmass_INPUTS, h0, s0)
        p0 = float(self._stagnation.p())
        T0 = float(self._stagnation.T())
        h_round_trip = float(self._stagnation.hmass())
        s_round_trip = float(self._stagnation.smass())

        numeric = (
            pressure,
            temperature,
            enthalpy,
            entropy,
            sound_speed,
            h0,
            s0,
            p0,
            T0,
            h_round_trip,
            s_round_trip,
        )
        if not all(math.isfinite(value) for value in numeric):
            raise ValueError("CoolProp reconstruction produced a nonfinite value")
        if pressure <= 0.0 or temperature <= 0.0 or sound_speed <= 0.0:
            raise ValueError("CoolProp reconstruction produced a nonpositive state")

        return StagnationReconstruction(
            static=AdjacentStaticState(
                pressure_pa=pressure,
                temperature_K=temperature,
                density_kg_m3=rho,
                internal_energy_J_kg=internal_energy,
                enthalpy_J_kg=enthalpy,
                entropy_J_kg_K=entropy,
                sound_speed_m_s=sound_speed,
                phase=phase,
                velocity_m_s=velocity,
            ),
            stagnation_pressure_pa=p0,
            stagnation_temperature_K=T0,
            stagnation_enthalpy_J_kg=h0,
            stagnation_entropy_J_kg_K=s0,
            enthalpy_round_trip_residual_J_kg=h_round_trip - h0,
            entropy_round_trip_residual_J_kg_K=s_round_trip - s0,
        )


class U3B2SinglePhaseCoolPropEOS:
    """Minimal real-fluid single-phase EOS for B2 FVM verification.

    This class exposes the existing solver's ``primitive_from_conserved``
    interface while retaining the same production-side Dmass/Umass property
    path used by the B2 Adapter. It is not a general two-phase CO2 EOS.
    """

    def __init__(
        self,
        *,
        provider: CoolPropAdjacentPropertyProvider | None = None,
        allowed_normalized_phases: tuple[str, ...] | None = None,
    ) -> None:
        self.provider = provider or CoolPropAdjacentPropertyProvider()
        self.allowed_normalized_phases = (
            None
            if allowed_normalized_phases is None
            else tuple(normalize_phase(value) for value in allowed_normalized_phases)
        )

    def primitive_from_conserved(self, U: np.ndarray) -> PrimitiveState:
        values = np.asarray(U, dtype=float)
        if values.ndim != 2 or values.shape[1] != N_VARS:
            raise ValueError(f"U must have shape (n_cells, {N_VARS})")
        reconstructions = [self.provider.reconstruct(row) for row in values]
        if self.allowed_normalized_phases is not None:
            allowed = set(self.allowed_normalized_phases)
            for index, reconstruction in enumerate(reconstructions):
                phase = normalize_phase(reconstruction.static.phase)
                if phase not in allowed:
                    raise ValueError(
                        f"cell {index} phase {reconstruction.static.phase!r} "
                        f"is outside {sorted(allowed)}"
                    )
        rho = values[:, IDX_RHO].copy()
        u = values[:, IDX_MOM] / rho
        E = values[:, IDX_RHOE] / rho
        e = E - 0.5 * u * u
        xv = values[:, IDX_RHO_XV] / rho
        p = np.array(
            [row.static.pressure_pa for row in reconstructions], dtype=float
        )
        T = np.array(
            [row.static.temperature_K for row in reconstructions], dtype=float
        )
        c = np.array(
            [row.static.sound_speed_m_s for row in reconstructions], dtype=float
        )
        alpha = np.zeros_like(rho)
        return PrimitiveState(
            rho=rho,
            u=u,
            p=p,
            e=e,
            E=E,
            T=T,
            xv=xv,
            alpha=alpha,
            c=c,
        )

    def density_from_pressure(self, p: np.ndarray | float) -> np.ndarray:
        raise NotImplementedError(
            "U3B2SinglePhaseCoolPropEOS supports transmissive B2 boundaries only"
        )


def conserved_from_locked_family(
    contract: Mapping[str, Any],
    state_id: str,
    *,
    provider: CoolPropAdjacentPropertyProvider | None = None,
    velocity_override_m_s: float | None = None,
    subcooling_override_K: float | None = None,
) -> np.ndarray:
    property_provider = provider or CoolPropAdjacentPropertyProvider()
    family = _state_family(contract, state_id)
    velocity = float(
        family.get("initial_velocity_m_s", 0.0)
        if velocity_override_m_s is None
        else velocity_override_m_s
    )
    pressure = float(family["pressure_pa"])
    if "temperature_K" in family:
        return property_provider.conserved_from_pressure_temperature(
            pressure,
            float(family["temperature_K"]),
            velocity_m_s=velocity,
        )
    subcooling = float(
        family["subcooling_K"]
        if subcooling_override_K is None
        else subcooling_override_K
    )
    return property_provider.conserved_from_pressure_subcooling(
        pressure,
        subcooling,
        velocity_m_s=velocity,
    )


def load_b2_contract(path: Path = DEFAULT_B2_CONTRACT_PATH) -> dict[str, Any]:
    contract = json.loads(path.read_text(encoding="utf-8"))
    if contract.get("schema_version") != CONTRACT_SCHEMA_VERSION:
        raise ValueError("unexpected U3 B2 contract schema")
    if contract.get("status") != "LOCKED_BEFORE_RESULTS":
        raise ValueError("U3 B2 contract is not locked")
    if contract.get("approval_boundary", {}).get("u3_b2_contract_locked") is not True:
        raise ValueError("u3_b2_contract_locked must be true")
    return contract


def load_b1_contract(path: Path = DEFAULT_B1_CONTRACT_PATH) -> dict[str, Any]:
    contract = json.loads(path.read_text(encoding="utf-8"))
    if contract.get("schema_version") != B1_CONTRACT_SCHEMA_VERSION:
        raise ValueError("unexpected U3 B1 contract schema")
    if contract.get("status") != "LOCKED_BEFORE_RESULTS":
        raise ValueError("U3 B1 contract is not locked")
    return contract


def _contract_case(contract: Mapping[str, Any], case_id: str) -> dict[str, Any]:
    for row in contract["benchmark_cases"]:
        if str(row["case_id"]) == case_id:
            return dict(row)
    raise KeyError(case_id)


def _state_family(contract: Mapping[str, Any], state_id: str) -> dict[str, Any]:
    for row in contract["fixed_state_families"]:
        if str(row["state_id"]) == state_id:
            return dict(row)
    raise KeyError(state_id)


def configuration_from_locked_case(
    contract: Mapping[str, Any],
    case_id: str,
) -> U3B2FaceConfiguration:
    row = _contract_case(contract, case_id)
    state_id = str(row["state_id"])
    family = _state_family(contract, state_id)
    tolerances = contract["acceptance_tolerances"]
    update = contract["time_step_and_update"]
    expected = str(row["expected_outcome"])
    if str(row.get("execution_level", "")) == "one_step":
        expected = SUCCESS_UNCHOKED_FACE_MAPPING
    return U3B2FaceConfiguration(
        case_id=case_id,
        state_id=state_id,
        expected_face_outcome=expected,
        back_pressure_pa=float(
            row.get("back_pressure_override_pa", family["back_pressure_pa"])
        ),
        opening_fraction=float(row.get("opening_fraction", 0.5)),
        discharge_coefficient=float(row.get("discharge_coefficient", 0.8)),
        pipe_area_m2=float(contract["geometry"]["pipe_area_m2"]),
        allowed_normalized_phases=tuple(
            normalize_phase(str(value))
            for value in family["allowed_normalized_phases"]
        ),
        velocity_zero_tolerance_m_s=float(
            tolerances["velocity_zero_tolerance_m_s"]
        ),
        stagnation_enthalpy_tolerance_J_kg=float(
            tolerances["stagnation_enthalpy_round_trip_absolute_J_kg"]
        ),
        stagnation_entropy_tolerance_J_kg_K=float(
            tolerances["stagnation_entropy_round_trip_absolute_J_kg_K"]
        ),
        mass_removal_fraction_limit=float(
            update["boundary_mass_removal_fraction_limit"]
        ),
        energy_removal_fraction_limit=float(
            update["boundary_energy_removal_fraction_limit"]
        ),
        maximum_halvings=int(update["deterministic_halving"]["maximum_halvings"]),
        nominal_static_pressure_pa=float(family["pressure_pa"]),
    )


def b1_state_id(b2_state_id: str) -> str:
    if b2_state_id == "LIQUID_SMALL_DROP":
        return "LIQUID_LIMIT"
    if b2_state_id in {"GAS_UNCHOKED", "GAS_CHOKED"}:
        return "GAS_CRITICAL"
    raise KeyError(b2_state_id)


def map_b1_outcome(value: str) -> str:
    return {
        _B1_SUCCESS_CLOSED: SUCCESS_CLOSED_WALL_MAPPING,
        _B1_SUCCESS_ZERO_DROP: SUCCESS_ZERO_DROP_WALL_IDENTITY,
        _B1_SUCCESS_UNCHOKED: SUCCESS_UNCHOKED_FACE_MAPPING,
        _B1_SUCCESS_CHOKED: SUCCESS_CHOKED_FACE_MAPPING,
        _B1_REVERSE_PRESSURE: REVERSE_PRESSURE_OR_FLOW_NOT_SUPPORTED,
        _B1_NONFINITE: NONFINITE_INPUT,
        _B1_OUTSIDE_SCOPE: ADJACENT_STATE_OUTSIDE_SINGLE_PHASE_SCOPE,
    }.get(value, value)


def physical_euler_flux(
    reconstruction: StagnationReconstruction,
) -> np.ndarray:
    state = reconstruction.static
    rho = state.density_kg_m3
    velocity = state.velocity_m_s
    rho_E = rho * (state.internal_energy_J_kg + 0.5 * velocity * velocity)
    return np.array(
        [
            rho * velocity,
            rho * velocity * velocity + state.pressure_pa,
            velocity * (rho_E + state.pressure_pa),
            0.0,
        ],
        dtype=float,
    )


class U3B2FvmDischargeAdapter:
    """Direct right external-face flux override for the locked U3 B2 scope."""

    def __init__(
        self,
        configuration: U3B2FaceConfiguration,
        *,
        b2_contract: Mapping[str, Any] | None = None,
        b1_contract: Mapping[str, Any] | None = None,
        property_provider: AdjacentPropertyProvider | None = None,
        b1_provider: Any | None = None,
        b1_evaluator: B1Evaluator = b1_adapter.evaluate_case,
    ) -> None:
        self.configuration = configuration
        self.b2_contract = dict(
            load_b2_contract() if b2_contract is None else b2_contract
        )
        self.b1_contract = dict(
            load_b1_contract() if b1_contract is None else b1_contract
        )
        self.property_provider = property_provider or CoolPropAdjacentPropertyProvider()
        self.b1_provider = b1_provider or b1_adapter.CoolPropStateProvider()
        self.b1_evaluator = b1_evaluator
        self._last_key: tuple[float, ...] | None = None
        self._last_result: U3B2FaceResult | None = None

    @classmethod
    def from_locked_case(
        cls,
        case_id: str,
        *,
        b2_contract_path: Path = DEFAULT_B2_CONTRACT_PATH,
        b1_contract_path: Path = DEFAULT_B1_CONTRACT_PATH,
        property_provider: AdjacentPropertyProvider | None = None,
        b1_provider: Any | None = None,
        b1_evaluator: B1Evaluator = b1_adapter.evaluate_case,
    ) -> "U3B2FvmDischargeAdapter":
        b2_contract = load_b2_contract(b2_contract_path)
        b1_contract = load_b1_contract(b1_contract_path)
        return cls(
            configuration_from_locked_case(b2_contract, case_id),
            b2_contract=b2_contract,
            b1_contract=b1_contract,
            property_provider=property_provider,
            b1_provider=b1_provider,
            b1_evaluator=b1_evaluator,
        )

    @property
    def maximum_update_halvings(self) -> int:
        return self.configuration.maximum_halvings

    @property
    def positivity_failure_outcome(self) -> str:
        return BOUNDARY_UPDATE_POSITIVITY_FAILURE

    @property
    def last_result(self) -> U3B2FaceResult | None:
        return self._last_result

    def _guard_result(
        self,
        outcome: str,
        message: str,
        *,
        reconstruction: StagnationReconstruction | None = None,
        raw_b1_outcome: str = "",
        raw_b1_message: str = "",
    ) -> U3B2FaceResult:
        cfg = self.configuration
        static = None if reconstruction is None else reconstruction.static
        return U3B2FaceResult(
            case_id=cfg.case_id,
            state_id=cfg.state_id,
            formal_outcome=outcome,
            formal_message=message,
            raw_b1_formal_outcome=raw_b1_outcome,
            raw_b1_message=raw_b1_message,
            upstream_static_pressure_pa=None if static is None else static.pressure_pa,
            upstream_static_temperature_K=None if static is None else static.temperature_K,
            upstream_density_kg_m3=None if static is None else static.density_kg_m3,
            upstream_internal_energy_J_kg=(
                None if static is None else static.internal_energy_J_kg
            ),
            upstream_enthalpy_J_kg=None if static is None else static.enthalpy_J_kg,
            upstream_entropy_J_kg_K=(
                None if static is None else static.entropy_J_kg_K
            ),
            upstream_sound_speed_m_s=(
                None if static is None else static.sound_speed_m_s
            ),
            upstream_phase=None if static is None else static.phase,
            adjacent_velocity_m_s=None if static is None else static.velocity_m_s,
            stagnation_pressure_pa=(
                None if reconstruction is None else reconstruction.stagnation_pressure_pa
            ),
            stagnation_temperature_K=(
                None
                if reconstruction is None
                else reconstruction.stagnation_temperature_K
            ),
            stagnation_enthalpy_J_kg=(
                None
                if reconstruction is None
                else reconstruction.stagnation_enthalpy_J_kg
            ),
            stagnation_entropy_J_kg_K=(
                None
                if reconstruction is None
                else reconstruction.stagnation_entropy_J_kg_K
            ),
            back_pressure_pa=cfg.back_pressure_pa,
            discharge_state_pressure_pa=None,
            critical_pressure_pa=None,
            opening_fraction=cfg.opening_fraction,
            discharge_coefficient=cfg.discharge_coefficient,
            pipe_area_m2=cfg.pipe_area_m2,
            open_area_m2=cfg.pipe_area_m2 * cfg.opening_fraction,
            closed_area_m2=cfg.pipe_area_m2 * (1.0 - cfg.opening_fraction),
            effective_velocity_m_s=0.0,
            mass_transfer_outward_kg_s=0.0,
            advective_momentum_rate_out_N=0.0,
            open_static_pressure_force_out_N=0.0,
            closed_static_pressure_force_out_N=0.0,
            total_momentum_rate_out_N=0.0,
            energy_transfer_outward_W=0.0,
            F_rho_kg_m2_s=0.0,
            F_rho_u_pa=0.0,
            F_rho_E_W_m2=0.0,
            F_rho_xv_kg_m2_s=0.0,
            pressure_decomposition_residual_pa=0.0,
            zero_drop_canonicalization_applied=False,
        )

    def _b1_contract_for_reconstruction(
        self,
        reconstruction: StagnationReconstruction,
    ) -> dict[str, Any]:
        contract = copy.deepcopy(self.b1_contract)
        target = b1_state_id(self.configuration.state_id)
        for family in contract["upstream_state_families"]:
            if str(family["state_id"]) != target:
                continue
            family["pressure_pa"] = reconstruction.stagnation_pressure_pa
            family["temperature_K"] = reconstruction.stagnation_temperature_K
            family.pop("temperature_definition", None)
            family.pop("subcooling_K", None)
            return contract
        raise KeyError(target)

    def _evaluate_b1(
        self,
        reconstruction: StagnationReconstruction,
    ) -> B1ResultLike:
        cfg = self.configuration
        case = {
            "case_id": cfg.case_id,
            "state_id": b1_state_id(cfg.state_id),
            "back_pressure_pa": cfg.back_pressure_pa,
            "opening_fraction": cfg.opening_fraction,
            "discharge_coefficient": cfg.discharge_coefficient,
            "expected_outcome": "B2_ADAPTER_INPUT_ONLY",
        }
        return self.b1_evaluator(
            self._b1_contract_for_reconstruction(reconstruction),
            self.b1_provider,
            case,
            critical_cache={},
            critical_records=[],
        )

    def _locked_zero_drop_identity_applies(
        self,
        reconstruction: StagnationReconstruction,
        raw_b1_outcome: str,
    ) -> bool:
        cfg = self.configuration
        return (
            cfg.case_id == "B2-02_ZERO_DROP_LIQUID_WALL_IDENTITY"
            and cfg.expected_face_outcome == SUCCESS_ZERO_DROP_WALL_IDENTITY
            and cfg.back_pressure_pa == cfg.nominal_static_pressure_pa
            and cfg.opening_fraction == 0.5
            and cfg.discharge_coefficient == 0.8
            and reconstruction.static.velocity_m_s == 0.0
            and raw_b1_outcome.startswith("SUCCESS_")
        )

    def evaluate(self, adjacent_U: np.ndarray) -> U3B2FaceResult:
        values = np.asarray(adjacent_U, dtype=float)
        if values.shape != (N_VARS,):
            return self._guard_result(
                NONFINITE_INPUT,
                f"adjacent conserved state must have shape ({N_VARS},)",
            )
        key = tuple(float(value) for value in values)
        if self._last_key == key and self._last_result is not None:
            return self._last_result

        if not np.all(np.isfinite(values)):
            result = self._guard_result(
                NONFINITE_INPUT,
                "Adjacent conserved state contains NaN or infinity.",
            )
            self._last_key, self._last_result = key, result
            return result
        rho = float(values[IDX_RHO])
        if rho <= 0.0:
            result = self._guard_result(
                STAGNATION_RECONSTRUCTION_FAILURE,
                "Adjacent density must be positive.",
            )
            self._last_key, self._last_result = key, result
            return result
        velocity = float(values[IDX_MOM] / rho)
        if velocity < -self.configuration.velocity_zero_tolerance_m_s:
            result = self._guard_result(
                REVERSE_PRESSURE_OR_FLOW_NOT_SUPPORTED,
                "Adjacent velocity is negative beyond the locked tolerance; "
                "no reflective fallback is applied.",
            )
            self._last_key, self._last_result = key, result
            return result
        if float(values[IDX_RHO_XV]) != 0.0:
            result = self._guard_result(
                ADJACENT_STATE_OUTSIDE_SINGLE_PHASE_SCOPE,
                "Adjacent vapor-mass conserved variable must remain exact zero.",
            )
            self._last_key, self._last_result = key, result
            return result

        try:
            reconstruction = self.property_provider.reconstruct(values)
        except FloatingPointError as exc:
            result = self._guard_result(NONFINITE_INPUT, str(exc))
            self._last_key, self._last_result = key, result
            return result
        except Exception as exc:
            result = self._guard_result(
                STAGNATION_RECONSTRUCTION_FAILURE,
                f"Stagnation reconstruction failed: {type(exc).__name__}: {exc}",
            )
            self._last_key, self._last_result = key, result
            return result

        cfg = self.configuration
        if normalize_phase(reconstruction.static.phase) not in set(
            cfg.allowed_normalized_phases
        ):
            result = self._guard_result(
                ADJACENT_STATE_OUTSIDE_SINGLE_PHASE_SCOPE,
                f"Adjacent phase {reconstruction.static.phase!r} is outside "
                f"{sorted(cfg.allowed_normalized_phases)}.",
                reconstruction=reconstruction,
            )
            self._last_key, self._last_result = key, result
            return result
        if (
            abs(reconstruction.enthalpy_round_trip_residual_J_kg)
            > cfg.stagnation_enthalpy_tolerance_J_kg
            or abs(reconstruction.entropy_round_trip_residual_J_kg_K)
            > cfg.stagnation_entropy_tolerance_J_kg_K
        ):
            result = self._guard_result(
                STAGNATION_RECONSTRUCTION_FAILURE,
                "Stagnation Hmass/Smass round-trip exceeds the locked tolerance.",
                reconstruction=reconstruction,
            )
            self._last_key, self._last_result = key, result
            return result

        try:
            b1_result = self._evaluate_b1(reconstruction)
        except Exception as exc:
            result = self._guard_result(
                STAGNATION_RECONSTRUCTION_FAILURE,
                f"Accepted B1 adapter invocation failed: {type(exc).__name__}: {exc}",
                reconstruction=reconstruction,
            )
            self._last_key, self._last_result = key, result
            return result

        raw_outcome = str(b1_result.formal_outcome)
        raw_message = str(b1_result.formal_message)
        mapped_outcome = map_b1_outcome(raw_outcome)
        canonical_zero_drop = self._locked_zero_drop_identity_applies(
            reconstruction,
            raw_outcome,
        )
        if canonical_zero_drop:
            formal_outcome = SUCCESS_ZERO_DROP_WALL_IDENTITY
            mass = 0.0
            advective = 0.0
            energy = 0.0
            effective_velocity = 0.0
            p_d = reconstruction.static.pressure_pa
            message = (
                "Locked B2-02 static-coordinate zero-drop identity retained "
                f"exactly; raw B1 outcome={raw_outcome}. No B1 law, contract "
                "value, or tolerance was changed."
            )
        else:
            formal_outcome = mapped_outcome
            if not formal_outcome.startswith("SUCCESS_"):
                result = self._guard_result(
                    formal_outcome,
                    raw_message,
                    reconstruction=reconstruction,
                    raw_b1_outcome=raw_outcome,
                    raw_b1_message=raw_message,
                )
                self._last_key, self._last_result = key, result
                return result
            mass = float(b1_result.mass_transfer_outward_kg_s)
            advective = float(b1_result.momentum_stream_transfer_outward_N)
            energy = float(b1_result.energy_transfer_outward_W)
            effective_velocity = float(b1_result.effective_velocity_m_s)
            if formal_outcome in {
                SUCCESS_CLOSED_WALL_MAPPING,
                SUCCESS_ZERO_DROP_WALL_IDENTITY,
            }:
                p_d = reconstruction.static.pressure_pa
            else:
                if b1_result.evaluation_pressure_pa is None:
                    result = self._guard_result(
                        STAGNATION_RECONSTRUCTION_FAILURE,
                        "Successful B1 stream lacks an evaluation pressure.",
                        reconstruction=reconstruction,
                        raw_b1_outcome=raw_outcome,
                        raw_b1_message=raw_message,
                    )
                    self._last_key, self._last_result = key, result
                    return result
                p_d = float(b1_result.evaluation_pressure_pa)
            message = (
                "Production-side B2 face mapping constructed from accepted B1 "
                "stream transfer and separately retained static pressure forces."
            )

        p_i = reconstruction.static.pressure_pa
        open_area = cfg.pipe_area_m2 * cfg.opening_fraction
        closed_area = cfg.pipe_area_m2 - open_area
        open_pressure = p_d * open_area
        closed_pressure = p_i * closed_area
        total_momentum = advective + open_pressure + closed_pressure
        F_rho = mass / cfg.pipe_area_m2
        F_rho_u = total_momentum / cfg.pipe_area_m2
        F_rho_E = energy / cfg.pipe_area_m2
        reconstructed_momentum_flux = (
            advective / cfg.pipe_area_m2
            + p_d * cfg.opening_fraction
            + p_i * (1.0 - cfg.opening_fraction)
        )
        pressure_residual = F_rho_u - reconstructed_momentum_flux
        numeric = (
            p_d,
            mass,
            advective,
            energy,
            effective_velocity,
            open_pressure,
            closed_pressure,
            total_momentum,
            F_rho,
            F_rho_u,
            F_rho_E,
            pressure_residual,
        )
        if not all(math.isfinite(value) for value in numeric):
            result = self._guard_result(
                STAGNATION_RECONSTRUCTION_FAILURE,
                "B2 face mapping produced a nonfinite value.",
                reconstruction=reconstruction,
                raw_b1_outcome=raw_outcome,
                raw_b1_message=raw_message,
            )
            self._last_key, self._last_result = key, result
            return result

        result = U3B2FaceResult(
            case_id=cfg.case_id,
            state_id=cfg.state_id,
            formal_outcome=formal_outcome,
            formal_message=message,
            raw_b1_formal_outcome=raw_outcome,
            raw_b1_message=raw_message,
            upstream_static_pressure_pa=p_i,
            upstream_static_temperature_K=reconstruction.static.temperature_K,
            upstream_density_kg_m3=reconstruction.static.density_kg_m3,
            upstream_internal_energy_J_kg=(
                reconstruction.static.internal_energy_J_kg
            ),
            upstream_enthalpy_J_kg=reconstruction.static.enthalpy_J_kg,
            upstream_entropy_J_kg_K=reconstruction.static.entropy_J_kg_K,
            upstream_sound_speed_m_s=reconstruction.static.sound_speed_m_s,
            upstream_phase=reconstruction.static.phase,
            adjacent_velocity_m_s=reconstruction.static.velocity_m_s,
            stagnation_pressure_pa=reconstruction.stagnation_pressure_pa,
            stagnation_temperature_K=reconstruction.stagnation_temperature_K,
            stagnation_enthalpy_J_kg=reconstruction.stagnation_enthalpy_J_kg,
            stagnation_entropy_J_kg_K=reconstruction.stagnation_entropy_J_kg_K,
            back_pressure_pa=cfg.back_pressure_pa,
            discharge_state_pressure_pa=p_d,
            critical_pressure_pa=b1_result.critical_pressure_pa,
            opening_fraction=cfg.opening_fraction,
            discharge_coefficient=cfg.discharge_coefficient,
            pipe_area_m2=cfg.pipe_area_m2,
            open_area_m2=open_area,
            closed_area_m2=closed_area,
            effective_velocity_m_s=effective_velocity,
            mass_transfer_outward_kg_s=mass,
            advective_momentum_rate_out_N=advective,
            open_static_pressure_force_out_N=open_pressure,
            closed_static_pressure_force_out_N=closed_pressure,
            total_momentum_rate_out_N=total_momentum,
            energy_transfer_outward_W=energy,
            F_rho_kg_m2_s=F_rho,
            F_rho_u_pa=F_rho_u,
            F_rho_E_W_m2=F_rho_E,
            F_rho_xv_kg_m2_s=0.0,
            pressure_decomposition_residual_pa=pressure_residual,
            zero_drop_canonicalization_applied=canonical_zero_drop,
        )
        self._last_key, self._last_result = key, result
        return result

    def evaluate_flux(
        self,
        *,
        adjacent_U: np.ndarray,
        eos: EOSModel,
        t: float,
    ) -> np.ndarray:
        del eos, t
        return self.evaluate(adjacent_U).flux_vector()

    def _limit_dt_from_face(
        self,
        adjacent_U: np.ndarray,
        face: U3B2FaceResult,
        *,
        dx_m: float,
        area_m2: float,
        candidate_dt_s: float,
    ) -> tuple[float, float, float]:
        if dx_m <= 0.0 or area_m2 <= 0.0 or candidate_dt_s <= 0.0:
            raise ValueError("dx, area, and candidate dt must be positive")
        if area_m2 != self.configuration.pipe_area_m2:
            raise ValueError("solver pipe area does not match the locked B2 area")
        if not face.succeeded:
            raise U3B2FaceGuardError(face.formal_outcome, face.formal_message)
        cell_volume = area_m2 * dx_m
        mass_dt = math.inf
        if face.mass_transfer_outward_kg_s > 0.0:
            mass_dt = (
                self.configuration.mass_removal_fraction_limit
                * float(adjacent_U[IDX_RHO])
                * cell_volume
                / face.mass_transfer_outward_kg_s
            )
        energy_dt = math.inf
        if face.energy_transfer_outward_W > 0.0:
            energy_dt = (
                self.configuration.energy_removal_fraction_limit
                * float(adjacent_U[IDX_RHOE])
                * cell_volume
                / face.energy_transfer_outward_W
            )
        accepted = min(float(candidate_dt_s), mass_dt, energy_dt)
        return accepted, mass_dt, energy_dt

    def limit_dt(
        self,
        *,
        adjacent_U: np.ndarray,
        eos: EOSModel,
        t: float,
        dx_m: float,
        area_m2: float,
        candidate_dt_s: float,
    ) -> float:
        del eos, t
        values = np.asarray(adjacent_U, dtype=float)
        face = self.evaluate(values)
        accepted, _, _ = self._limit_dt_from_face(
            values,
            face,
            dx_m=dx_m,
            area_m2=area_m2,
            candidate_dt_s=candidate_dt_s,
        )
        return accepted

    def validate_trial_state(
        self,
        *,
        U_new: np.ndarray,
        eos: EOSModel,
        t: float,
        dt: float,
    ) -> None:
        del eos, t
        values = np.asarray(U_new, dtype=float)
        if values.ndim != 2 or values.shape[1] != N_VARS:
            raise ValueError(f"trial U must have shape (n_cells, {N_VARS})")
        if dt <= 0.0 or not math.isfinite(dt):
            raise ValueError("trial dt must be positive and finite")
        if not np.all(np.isfinite(values)):
            raise ValueError("trial state contains NaN or infinity")
        if np.any(values[:, IDX_RHO] <= 0.0):
            raise ValueError("trial density must remain positive")
        if np.any(values[:, IDX_RHO_XV] != 0.0):
            raise ValueError("trial rho*xv must remain exact zero")

        allowed = set(self.configuration.allowed_normalized_phases)
        for index, row in enumerate(values):
            rho = float(row[IDX_RHO])
            velocity = float(row[IDX_MOM] / rho)
            internal_energy = float(row[IDX_RHOE] / rho) - 0.5 * velocity * velocity
            if not math.isfinite(internal_energy) or internal_energy <= 0.0:
                raise ValueError(
                    f"trial internal energy must remain positive at cell {index}"
                )
            try:
                reconstruction = self.property_provider.reconstruct(row)
            except Exception as exc:
                raise ValueError(
                    f"trial property reconstruction failed at cell {index}: "
                    f"{type(exc).__name__}: {exc}"
                ) from exc
            if normalize_phase(reconstruction.static.phase) not in allowed:
                raise ValueError(
                    f"trial cell {index} phase {reconstruction.static.phase!r} "
                    f"is outside {sorted(allowed)}"
                )

    def one_step_reference_like_balance(
        self,
        adjacent_U: np.ndarray,
        *,
        cells: int,
        cfl: float,
        pipe_length_m: float,
    ) -> U3B2OneStepResult:
        if cells <= 0 or pipe_length_m <= 0.0 or not 0.0 < cfl <= 1.0:
            raise ValueError("cells, length, and cfl must be valid")
        face = self.evaluate(adjacent_U)
        if not face.succeeded:
            raise U3B2FaceGuardError(face.formal_outcome, face.formal_message)
        reconstruction = self.property_provider.reconstruct(
            np.asarray(adjacent_U, dtype=float)
        )
        left_flux_array = physical_euler_flux(reconstruction)
        right_flux_array = face.flux_vector()
        dx = pipe_length_m / cells
        cfl_dt = cfl * dx / (
            abs(reconstruction.static.velocity_m_s)
            + reconstruction.static.sound_speed_m_s
        )
        values = np.asarray(adjacent_U, dtype=float)
        candidate_dt, mass_dt, energy_dt = self._limit_dt_from_face(
            values,
            face,
            dx_m=dx,
            area_m2=self.configuration.pipe_area_m2,
            candidate_dt_s=cfl_dt,
        )

        accepted_dt = candidate_dt
        U_before = np.asarray(adjacent_U, dtype=float)
        U_after = U_before.copy()
        halving_count = 0
        for halving_count in range(self.maximum_update_halvings + 1):
            U_after = U_before - accepted_dt / dx * (
                right_flux_array - left_flux_array
            )
            rho = float(U_after[IDX_RHO])
            valid = bool(np.all(np.isfinite(U_after)) and rho > 0.0)
            if valid:
                velocity = float(U_after[IDX_MOM] / rho)
                internal_energy = (
                    float(U_after[IDX_RHOE] / rho) - 0.5 * velocity * velocity
                )
                valid = internal_energy > 0.0 and float(U_after[IDX_RHO_XV]) == 0.0
            if valid:
                break
            if halving_count >= self.maximum_update_halvings:
                raise U3B2FaceGuardError(
                    BOUNDARY_UPDATE_POSITIVITY_FAILURE,
                    "All deterministic boundary-update halvings remained nonphysical.",
                )
            accepted_dt *= 0.5

        direct = U_before - accepted_dt / dx * (
            right_flux_array - left_flux_array
        )
        scale = max(float(np.max(np.abs(direct))), 1.0)
        normalized = float(np.max(np.abs(U_after - direct)) / scale)
        area = self.configuration.pipe_area_m2
        initial_mass = float(U_before[IDX_RHO] * area * pipe_length_m)
        initial_momentum = float(U_before[IDX_MOM] * area * pipe_length_m)
        initial_energy = float(U_before[IDX_RHOE] * area * pipe_length_m)
        initial_vapor = float(U_before[IDX_RHO_XV] * area * pipe_length_m)
        final_mass = initial_mass + area * dx * float(
            U_after[IDX_RHO] - U_before[IDX_RHO]
        )
        final_momentum = initial_momentum + area * dx * float(
            U_after[IDX_MOM] - U_before[IDX_MOM]
        )
        final_energy = initial_energy + area * dx * float(
            U_after[IDX_RHOE] - U_before[IDX_RHOE]
        )
        final_vapor = initial_vapor + area * dx * float(
            U_after[IDX_RHO_XV] - U_before[IDX_RHO_XV]
        )
        mass_residual = (
            final_mass
            + face.mass_transfer_outward_kg_s * accepted_dt
            - initial_mass
        )
        energy_residual = (
            final_energy
            + face.energy_transfer_outward_W * accepted_dt
            - initial_energy
        )
        momentum_expected = initial_momentum + area * accepted_dt * (
            float(left_flux_array[IDX_MOM]) - float(right_flux_array[IDX_MOM])
        )
        momentum_residual = final_momentum - momentum_expected
        vapor_residual = final_vapor - initial_vapor
        return U3B2OneStepResult(
            formal_outcome=SUCCESS_ONE_STEP,
            accepted_dt_s=accepted_dt,
            halving_count=halving_count,
            cfl_dt_s=cfl_dt,
            mass_removal_dt_s=mass_dt,
            energy_removal_dt_s=energy_dt,
            U_before=tuple(float(value) for value in U_before),
            left_flux=tuple(float(value) for value in left_flux_array),
            right_flux=tuple(float(value) for value in right_flux_array),
            U_after=tuple(float(value) for value in U_after),
            normalized_balance_residual=normalized,
            mass_inventory_residual_kg=mass_residual,
            momentum_inventory_residual_kg_m_s=momentum_residual,
            energy_inventory_residual_J=energy_residual,
            vapor_inventory_residual_kg=vapor_residual,
        )
