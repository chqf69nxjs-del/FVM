from __future__ import annotations

import inspect
import math
from functools import lru_cache
from pathlib import Path

import numpy as np
import pytest

from liquid_gas_transient import u3_b1_critical_state_reference as b1_ref
from liquid_gas_transient import u3_b2_fvm_discharge_adapter as adapter
from liquid_gas_transient import u3_b2_fvm_discharge_reference as reference
from liquid_gas_transient import (
    u3_b2_fvm_discharge_reference_authoritative as reference_authoritative,
)
from liquid_gas_transient.boundary import ReflectiveBoundary, TransmissiveBoundary
from liquid_gas_transient.config import PipeGeometry
from liquid_gas_transient.grid import UniformGrid
from liquid_gas_transient.solver import ExternalFaceUpdateFailure, FvmSolver
from liquid_gas_transient.state import inventory


PARENT = Path(
    "docs/verification/stage7_u3_b2_fvm_discharge_coupling_contract_v1.json"
)
EXTENSION = Path(
    "docs/verification/"
    "stage7_u3_b2_fvm_discharge_coupling_event_provenance_contract_v1.json"
)
B1_CONTRACT = Path(
    "docs/verification/stage7_u3_b1_critical_state_contract_v1.json"
)


@lru_cache(maxsize=1)
def _reference_package() -> reference.ReferencePackage:
    reference_authoritative.install_authoritative_interpretation()
    return reference.evaluate_reference(
        reference.load_contract(PARENT),
        reference.load_extension(EXTENSION),
        b1_ref.load_contract(B1_CONTRACT),
    )


def _conserved_from_reference_face(row: reference.FaceReference) -> np.ndarray:
    rho = float(row.upstream_density_kg_m3)
    velocity = float(row.adjacent_velocity_m_s)
    internal_energy = float(row.upstream_internal_energy_J_kg)
    return np.array(
        [
            rho,
            rho * velocity,
            rho * (internal_energy + 0.5 * velocity * velocity),
            0.0,
        ],
        dtype=float,
    )


def _within(actual: float, expected: float, absolute: float, relative: float) -> bool:
    return abs(actual - expected) <= absolute + relative * abs(expected)


def test_adapter_source_is_independent_of_b2_reference() -> None:
    source = Path(inspect.getfile(adapter)).read_text(encoding="utf-8")
    assert "u3_b2_fvm_discharge_reference" not in source
    assert "PropsSI" not in source
    assert "DmassUmass_INPUTS" in source
    assert "HmassSmass_INPUTS" in source


def test_locked_face_matrix_matches_independent_reference() -> None:
    contract = adapter.load_b2_contract(PARENT)
    tolerances = contract["acceptance_tolerances"]
    package = _reference_package()
    assert len(package.face_rows) == 13

    for expected in package.face_rows:
        boundary = adapter.U3B2FvmDischargeAdapter.from_locked_case(
            expected.case_id,
            b2_contract_path=PARENT,
            b1_contract_path=B1_CONTRACT,
        )
        actual = boundary.evaluate(_conserved_from_reference_face(expected))
        assert actual.formal_outcome == expected.formal_outcome, expected.case_id
        assert actual.succeeded, expected.case_id
        assert _within(
            actual.F_rho_kg_m2_s,
            expected.F_rho_kg_m2_s,
            float(tolerances["reference_adapter_mass_flux_absolute_kg_m2_s"]),
            float(tolerances["reference_adapter_mass_flux_relative"]),
        ), expected.case_id
        assert _within(
            actual.F_rho_u_pa,
            expected.F_rho_u_pa,
            float(tolerances["reference_adapter_momentum_flux_absolute_pa"]),
            float(tolerances["reference_adapter_momentum_flux_relative"]),
        ), expected.case_id
        assert _within(
            actual.F_rho_E_W_m2,
            expected.F_rho_E_W_m2,
            float(tolerances["reference_adapter_energy_flux_absolute_W_m2"]),
            float(tolerances["reference_adapter_energy_flux_relative"]),
        ), expected.case_id
        assert actual.F_rho_xv_kg_m2_s == 0.0
        assert abs(actual.pressure_decomposition_residual_pa) <= float(
            tolerances["pressure_decomposition_reconstruction_absolute_pa"]
        )


def test_closed_and_zero_drop_identities_are_exact() -> None:
    by_id = {row.case_id: row for row in _reference_package().face_rows}
    identity_ids = (
        "B2-01_CLOSED_LIQUID_WALL_IDENTITY",
        "B2-02_ZERO_DROP_LIQUID_WALL_IDENTITY",
        "B2-03_CLOSED_GAS_WALL_IDENTITY",
    )
    for case_id in identity_ids:
        boundary = adapter.U3B2FvmDischargeAdapter.from_locked_case(case_id)
        result = boundary.evaluate(_conserved_from_reference_face(by_id[case_id]))
        assert result.F_rho_kg_m2_s == 0.0
        assert result.F_rho_u_pa == result.upstream_static_pressure_pa
        assert result.F_rho_E_W_m2 == 0.0
        assert result.F_rho_xv_kg_m2_s == 0.0

    zero_drop = adapter.U3B2FvmDischargeAdapter.from_locked_case(
        "B2-02_ZERO_DROP_LIQUID_WALL_IDENTITY"
    ).evaluate(
        _conserved_from_reference_face(
            by_id["B2-02_ZERO_DROP_LIQUID_WALL_IDENTITY"]
        )
    )
    assert zero_drop.zero_drop_canonicalization_applied is True
    assert zero_drop.raw_b1_formal_outcome.startswith("SUCCESS_")
    assert "No B1 law, contract value, or tolerance was changed" in (
        zero_drop.formal_message
    )


def test_face_guards_fire_before_flux_construction() -> None:
    package = _reference_package()
    by_id = {row.case_id: row for row in package.face_rows}
    normal = _conserved_from_reference_face(
        by_id["B2-04_SMALL_DROP_RECOVERS_B0_FACE_LIMIT"]
    )

    reverse_pressure = adapter.U3B2FvmDischargeAdapter.from_locked_case(
        "G-01_REVERSE_PRESSURE"
    ).evaluate(normal)
    assert (
        reverse_pressure.formal_outcome
        == adapter.REVERSE_PRESSURE_OR_FLOW_NOT_SUPPORTED
    )

    reverse_velocity_state = normal.copy()
    reverse_velocity_state[1] = -0.01 * reverse_velocity_state[0]
    reverse_velocity = adapter.U3B2FvmDischargeAdapter.from_locked_case(
        "G-02_REVERSE_ADJACENT_VELOCITY"
    ).evaluate(reverse_velocity_state)
    assert (
        reverse_velocity.formal_outcome
        == adapter.REVERSE_PRESSURE_OR_FLOW_NOT_SUPPORTED
    )

    nonfinite = normal.copy()
    nonfinite[2] = math.nan
    nonfinite_result = adapter.U3B2FvmDischargeAdapter.from_locked_case(
        "G-03_NONFINITE_ADJACENT_STATE"
    ).evaluate(nonfinite)
    assert nonfinite_result.formal_outcome == adapter.NONFINITE_INPUT

    nonzero_vapor = normal.copy()
    nonzero_vapor[3] = 1.0
    scope = adapter.U3B2FvmDischargeAdapter.from_locked_case(
        "G-04_SINGLE_PHASE_SCOPE_FAILURE"
    ).evaluate(nonzero_vapor)
    assert (
        scope.formal_outcome
        == adapter.ADJACENT_STATE_OUTSIDE_SINGLE_PHASE_SCOPE
    )


class _AlwaysFailingPropertyProvider:
    version = "synthetic"

    def reconstruct(self, conserved: np.ndarray):
        raise RuntimeError("synthetic Hmass/Smass inversion failure")


def test_stagnation_reconstruction_guard_is_atomic() -> None:
    reference_face = {
        row.case_id: row for row in _reference_package().face_rows
    }["B2-05_UNCHOKED_INITIAL_FACE_MATCHES_B1"]
    boundary = adapter.U3B2FvmDischargeAdapter.from_locked_case(
        "G-05_STAGNATION_RECONSTRUCTION_FAILURE",
        property_provider=_AlwaysFailingPropertyProvider(),
    )
    result = boundary.evaluate(_conserved_from_reference_face(reference_face))
    assert result.formal_outcome == adapter.STAGNATION_RECONSTRUCTION_FAILURE
    with pytest.raises(adapter.U3B2FaceGuardError) as captured:
        result.flux_vector()
    assert captured.value.outcome == adapter.STAGNATION_RECONSTRUCTION_FAILURE


def test_adapter_one_step_algebra_matches_independent_reference() -> None:
    package = _reference_package()
    expected = package.one_step
    face = {
        row.case_id: row for row in package.face_rows
    }["B2-09_ONE_STEP_UNCHOKED_CONSERVATIVE_UPDATE"]
    boundary = adapter.U3B2FvmDischargeAdapter.from_locked_case(face.case_id)
    actual = boundary.one_step_reference_like_balance(
        _conserved_from_reference_face(face),
        cells=expected.cells,
        cfl=expected.cfl,
        pipe_length_m=1.0,
    )
    tolerance = float(
        adapter.load_b2_contract(PARENT)["acceptance_tolerances"][
            "one_step_normalized_state_absolute"
        ]
    )
    expected_after = np.array(
        [
            expected.U_after_rho,
            expected.U_after_rho_u,
            expected.U_after_rho_E,
            expected.U_after_rho_xv,
        ],
        dtype=float,
    )
    actual_after = np.array(actual.U_after, dtype=float)
    normalized = float(
        np.max(np.abs(actual_after - expected_after))
        / max(float(np.max(np.abs(expected_after))), 1.0)
    )
    assert actual.formal_outcome == adapter.SUCCESS_ONE_STEP
    assert normalized <= tolerance
    assert actual.normalized_balance_residual <= tolerance
    assert actual.mass_inventory_residual_kg == pytest.approx(0.0, abs=1.0e-12)
    assert actual.energy_inventory_residual_J == pytest.approx(0.0, abs=1.0e-5)
    assert actual.momentum_inventory_residual_kg_m_s == pytest.approx(
        0.0, abs=1.0e-10
    )
    assert actual.vapor_inventory_residual_kg == 0.0


def test_existing_solver_executes_direct_face_override_before_budget() -> None:
    package = _reference_package()
    expected = package.one_step
    face = {
        row.case_id: row for row in package.face_rows
    }["B2-09_ONE_STEP_UNCHOKED_CONSERVATIVE_UPDATE"]
    U_cell = _conserved_from_reference_face(face)
    U = np.repeat(U_cell[np.newaxis, :], expected.cells, axis=0)
    contract = adapter.load_b2_contract(PARENT)
    diameter = float(contract["geometry"]["pipe_diameter_m"])
    grid = UniformGrid(
        PipeGeometry(length_m=1.0, diameter_m=diameter),
        n_cells=expected.cells,
    )
    provider = adapter.CoolPropAdjacentPropertyProvider()
    boundary = adapter.U3B2FvmDischargeAdapter.from_locked_case(
        face.case_id,
        property_provider=provider,
    )
    eos = adapter.U3B2SinglePhaseCoolPropEOS(
        provider=provider,
        allowed_normalized_phases=boundary.configuration.allowed_normalized_phases,
    )
    solver = FvmSolver(
        grid=grid,
        eos=eos,
        U=U,
        cfl=expected.cfl,
        n_ghost=2,
        left_boundary=ReflectiveBoundary(),
        right_boundary=TransmissiveBoundary(),
        right_external_face_flux_override=boundary,
        enable_boundary_budget=True,
        enable_phase_budget=False,
        enable_energy_budget=False,
        enable_interface_budget=False,
    )

    computed_dt = solver.compute_dt()
    accepted_dt = solver.step(computed_dt)
    expected_after = np.array(
        [
            expected.U_after_rho,
            expected.U_after_rho_u,
            expected.U_after_rho_E,
            expected.U_after_rho_xv,
        ],
        dtype=float,
    )
    normalized = float(
        np.max(np.abs(solver.U[-1] - expected_after))
        / max(float(np.max(np.abs(expected_after))), 1.0)
    )
    tolerances = contract["acceptance_tolerances"]
    assert accepted_dt == pytest.approx(expected.accepted_dt_s, rel=2.0e-6)
    assert normalized <= float(tolerances["one_step_normalized_state_absolute"])
    assert solver.last_update_halving_count == 0
    assert solver.boundary_budget is not None
    assert np.array_equal(
        solver.boundary_budget.last_right_flux,
        boundary.last_result.flux_vector(),
    )
    diagnostics = solver.boundary_budget.diagnostics(
        inventory(solver.U, grid.dx, grid.geometry.area_m2)
    )
    assert abs(diagnostics["budget_mass_residual"]) <= float(
        tolerances["mass_inventory_absolute_kg"]
    )
    assert abs(diagnostics["budget_energy_residual"]) <= float(
        tolerances["energy_inventory_absolute_J"]
    )
    assert abs(diagnostics["budget_momentum_residual"]) <= float(
        tolerances["momentum_inventory_absolute_kg_m_s"]
    )
    assert diagnostics["budget_vapor_mass_residual"] == 0.0


class _SyntheticInvalidUpdateOverride:
    maximum_update_halvings = 2
    positivity_failure_outcome = adapter.BOUNDARY_UPDATE_POSITIVITY_FAILURE

    def limit_dt(self, **kwargs) -> float:
        return float(kwargs["candidate_dt_s"])

    def evaluate_flux(self, **kwargs) -> np.ndarray:
        return np.zeros(4, dtype=float)

    def validate_trial_state(self, **kwargs) -> None:
        raise ValueError("synthetic nonpositive internal energy")


def test_boundary_update_exhaustion_does_not_mutate_budget_or_state() -> None:
    package = _reference_package()
    face = {
        row.case_id: row for row in package.face_rows
    }["B2-05_UNCHOKED_INITIAL_FACE_MATCHES_B1"]
    U_cell = _conserved_from_reference_face(face)
    U = np.repeat(U_cell[np.newaxis, :], 4, axis=0)
    contract = adapter.load_b2_contract(PARENT)
    grid = UniformGrid(
        PipeGeometry(
            length_m=1.0,
            diameter_m=float(contract["geometry"]["pipe_diameter_m"]),
        ),
        n_cells=4,
    )
    eos = adapter.U3B2SinglePhaseCoolPropEOS()
    solver = FvmSolver(
        grid=grid,
        eos=eos,
        U=U,
        cfl=0.1,
        n_ghost=2,
        right_external_face_flux_override=_SyntheticInvalidUpdateOverride(),
        enable_boundary_budget=True,
        enable_phase_budget=False,
        enable_energy_budget=False,
        enable_interface_budget=False,
    )
    before = solver.U.copy()
    assert solver.boundary_budget is not None
    with pytest.raises(ExternalFaceUpdateFailure) as captured:
        solver.step(solver.compute_dt())
    assert captured.value.outcome == adapter.BOUNDARY_UPDATE_POSITIVITY_FAILURE
    assert np.array_equal(solver.U, before)
    assert solver.t == 0.0
    assert solver.step_count == 0
    assert np.array_equal(solver.boundary_budget.cumulative_left, np.zeros(4))
    assert np.array_equal(solver.boundary_budget.cumulative_right, np.zeros(4))
