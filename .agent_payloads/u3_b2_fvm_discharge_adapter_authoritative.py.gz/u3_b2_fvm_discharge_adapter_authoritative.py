"""Authoritative U3 B2 Adapter face and one-step comparison runner.

The runner consumes an independently regenerated B2 Reference artifact.  It
never imports the B2 Reference Python module and therefore preserves the locked
Reference/Adapter implementation split.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import platform
import subprocess
import sys
from dataclasses import asdict
from pathlib import Path
from typing import Any, Mapping, Sequence

import matplotlib.pyplot as plt
import numpy as np

from . import u3_b2_fvm_discharge_adapter as adapter
from .boundary import ReflectiveBoundary, TransmissiveBoundary
from .config import PipeGeometry
from .grid import UniformGrid
from .solver import ExternalFaceUpdateFailure, FvmSolver
from .state import inventory

SCHEMA_VERSION = "stage7_u3_b2_fvm_adapter_face_one_step_v1"
FACE_RESULT_FILE = "adapter_face_results.csv"
FACE_COMPARISON_FILE = "reference_adapter_comparison.csv"
ONE_STEP_FILE = "one_step_conservative_update_comparison.csv"
GUARD_FILE = "guard_outcomes.csv"
CHECK_FILE = "locked_checks.csv"


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _write_csv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    rows = list(rows)
    if not rows:
        path.write_text("\n", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _float(row: Mapping[str, str], key: str) -> float:
    value = row[key]
    if value == "":
        return math.nan
    return float(value)


def _git_output(*args: str) -> str:
    try:
        return subprocess.check_output(
            ["git", *args], text=True, stderr=subprocess.DEVNULL
        ).strip()
    except Exception:
        return ""


def _provenance(
    *,
    source_git_sha: str,
    reference_source_git_sha: str,
    reference_artifact_id: int | None,
    reference_artifact_zip_sha256: str,
    reference_resolution_mode: str,
    property_backend_version: str,
) -> dict[str, Any]:
    return {
        "schema_version": "stage7_u3_b2_runtime_git_provenance_v1",
        "source_git_sha": source_git_sha,
        "analysis_source_git_sha": source_git_sha,
        "checkout_git_sha": _git_output("rev-parse", "HEAD"),
        "git_status_porcelain": _git_output(
            "status", "--porcelain=v1", "--untracked-files=no"
        ),
        "workflow_run_id": int(os.environ.get("GITHUB_RUN_ID", "0")),
        "workflow_run_attempt": int(os.environ.get("GITHUB_RUN_ATTEMPT", "0")),
        "runner_os": os.environ.get("RUNNER_OS", platform.system()),
        "python_version": platform.python_version(),
        "numpy_version": np.__version__,
        "property_backend": "CoolProp",
        "property_backend_version": property_backend_version,
        "reference_resolution_mode": reference_resolution_mode,
        "reference_source_git_sha": reference_source_git_sha,
        "reference_artifact_id": reference_artifact_id,
        "reference_artifact_zip_sha256": reference_artifact_zip_sha256,
        "case_or_matrix_identifier": "U3_B2_FACE_13_PLUS_ONE_STEP_ADAPTER",
        "model": "U3 B2 production-side single-phase discharge-face Adapter",
        "mapping_mode": "direct_external_face_flux_override",
        "finite_pipe_execution": False,
    }


def _within(
    actual: float,
    expected: float,
    *,
    absolute: float,
    relative: float,
) -> tuple[float, float, bool]:
    residual = actual - expected
    limit = absolute + relative * abs(expected)
    return residual, limit, abs(residual) <= limit


def _face_input(
    contract: Mapping[str, Any],
    case_id: str,
    provider: adapter.CoolPropAdjacentPropertyProvider,
) -> np.ndarray:
    case = next(
        row for row in contract["benchmark_cases"] if row["case_id"] == case_id
    )
    return adapter.conserved_from_locked_family(
        contract,
        str(case["state_id"]),
        provider=provider,
        velocity_override_m_s=(
            None
            if "adjacent_velocity_override_m_s" not in case
            else float(case["adjacent_velocity_override_m_s"])
        ),
        subcooling_override_K=(
            None
            if "upstream_subcooling_override_K" not in case
            else float(case["upstream_subcooling_override_K"])
        ),
    )


def _evaluate_faces(
    *,
    contract: Mapping[str, Any],
    b1_contract: Mapping[str, Any],
    reference_rows: Sequence[Mapping[str, str]],
) -> tuple[
    list[dict[str, Any]],
    list[dict[str, Any]],
    dict[str, adapter.U3B2FaceResult],
    dict[str, np.ndarray],
]:
    tolerances = contract["acceptance_tolerances"]
    result_rows: list[dict[str, Any]] = []
    comparison_rows: list[dict[str, Any]] = []
    results: dict[str, adapter.U3B2FaceResult] = {}
    inputs: dict[str, np.ndarray] = {}

    measures = (
        (
            "F_rho_kg_m2_s",
            "reference_adapter_mass_flux_absolute_kg_m2_s",
            "reference_adapter_mass_flux_relative",
        ),
        (
            "F_rho_u_pa",
            "reference_adapter_momentum_flux_absolute_pa",
            "reference_adapter_momentum_flux_relative",
        ),
        (
            "F_rho_E_W_m2",
            "reference_adapter_energy_flux_absolute_W_m2",
            "reference_adapter_energy_flux_relative",
        ),
    )

    for reference_row in reference_rows:
        case_id = str(reference_row["case_id"])
        provider = adapter.CoolPropAdjacentPropertyProvider()
        configuration = adapter.configuration_from_locked_case(contract, case_id)
        boundary = adapter.U3B2FvmDischargeAdapter(
            configuration,
            b2_contract=contract,
            b1_contract=b1_contract,
            property_provider=provider,
        )
        adjacent_U = _face_input(contract, case_id, provider)
        result = boundary.evaluate(adjacent_U)
        results[case_id] = result
        inputs[case_id] = adjacent_U
        row = asdict(result)
        row["expected_outcome"] = reference_row["formal_outcome"]
        row["outcome_matches_reference"] = (
            result.formal_outcome == reference_row["formal_outcome"]
        )
        row["adjacent_U_rho"] = float(adjacent_U[0])
        row["adjacent_U_rho_u"] = float(adjacent_U[1])
        row["adjacent_U_rho_E"] = float(adjacent_U[2])
        row["adjacent_U_rho_xv"] = float(adjacent_U[3])
        result_rows.append(row)

        for measure, absolute_key, relative_key in measures:
            actual = float(getattr(result, measure))
            expected = _float(reference_row, measure)
            residual, limit, passed = _within(
                actual,
                expected,
                absolute=float(tolerances[absolute_key]),
                relative=float(tolerances[relative_key]),
            )
            comparison_rows.append(
                {
                    "case_id": case_id,
                    "measure": measure,
                    "reference_value": expected,
                    "adapter_value": actual,
                    "residual": residual,
                    "absolute_tolerance": float(tolerances[absolute_key]),
                    "relative_tolerance": float(tolerances[relative_key]),
                    "combined_limit": limit,
                    "formal_outcome_match": (
                        result.formal_outcome
                        == reference_row["formal_outcome"]
                    ),
                    "comparison_passed": passed,
                }
            )

        comparison_rows.append(
            {
                "case_id": case_id,
                "measure": "F_rho_xv_kg_m2_s",
                "reference_value": _float(reference_row, "F_rho_xv_kg_m2_s"),
                "adapter_value": result.F_rho_xv_kg_m2_s,
                "residual": result.F_rho_xv_kg_m2_s
                - _float(reference_row, "F_rho_xv_kg_m2_s"),
                "absolute_tolerance": 0.0,
                "relative_tolerance": 0.0,
                "combined_limit": 0.0,
                "formal_outcome_match": (
                    result.formal_outcome == reference_row["formal_outcome"]
                ),
                "comparison_passed": (
                    result.F_rho_xv_kg_m2_s
                    == _float(reference_row, "F_rho_xv_kg_m2_s")
                    == 0.0
                ),
            }
        )

    return result_rows, comparison_rows, results, inputs


def _run_one_step(
    *,
    contract: Mapping[str, Any],
    b1_contract: Mapping[str, Any],
    reference_row: Mapping[str, str],
) -> dict[str, Any]:
    case_id = str(reference_row["case_id"])
    provider = adapter.CoolPropAdjacentPropertyProvider()
    configuration = adapter.configuration_from_locked_case(contract, case_id)
    boundary = adapter.U3B2FvmDischargeAdapter(
        configuration,
        b2_contract=contract,
        b1_contract=b1_contract,
        property_provider=provider,
    )
    adjacent_U = _face_input(contract, case_id, provider)
    cells = int(reference_row["cells"])
    cfl = float(reference_row["cfl"])
    helper = boundary.one_step_reference_like_balance(
        adjacent_U,
        cells=cells,
        cfl=cfl,
        pipe_length_m=float(contract["geometry"]["pipe_length_m"]),
    )

    U = np.repeat(adjacent_U[np.newaxis, :], cells, axis=0)
    grid = UniformGrid(
        PipeGeometry(
            length_m=float(contract["geometry"]["pipe_length_m"]),
            diameter_m=float(contract["geometry"]["pipe_diameter_m"]),
        ),
        n_cells=cells,
    )
    eos = adapter.U3B2SinglePhaseCoolPropEOS(
        provider=provider,
        allowed_normalized_phases=configuration.allowed_normalized_phases,
    )
    solver = FvmSolver(
        grid=grid,
        eos=eos,
        U=U,
        cfl=cfl,
        n_ghost=int(contract["geometry"]["ghost_cells_each_side"]),
        left_boundary=ReflectiveBoundary(),
        right_boundary=TransmissiveBoundary(),
        right_external_face_flux_override=boundary,
        enable_boundary_budget=True,
        enable_phase_budget=False,
        enable_energy_budget=False,
        enable_interface_budget=False,
    )
    requested_dt = solver.compute_dt()
    accepted_dt = solver.step(requested_dt)
    if solver.boundary_budget is None:
        raise RuntimeError("one-step execution requires boundary budget")
    budget = solver.boundary_budget.diagnostics(
        inventory(solver.U, grid.dx, grid.geometry.area_m2)
    )
    reference_after = np.array(
        [
            _float(reference_row, "U_after_rho"),
            _float(reference_row, "U_after_rho_u"),
            _float(reference_row, "U_after_rho_E"),
            _float(reference_row, "U_after_rho_xv"),
        ],
        dtype=float,
    )
    actual_after = solver.U[-1].copy()
    normalized = float(
        np.max(np.abs(actual_after - reference_after))
        / max(float(np.max(np.abs(reference_after))), 1.0)
    )
    return {
        "case_id": case_id,
        "cells": cells,
        "cfl": cfl,
        "reference_accepted_dt_s": _float(reference_row, "accepted_dt_s"),
        "helper_accepted_dt_s": helper.accepted_dt_s,
        "solver_requested_dt_s": requested_dt,
        "solver_accepted_dt_s": accepted_dt,
        "solver_halving_count": solver.last_update_halving_count,
        "reference_U_after_rho": reference_after[0],
        "reference_U_after_rho_u": reference_after[1],
        "reference_U_after_rho_E": reference_after[2],
        "reference_U_after_rho_xv": reference_after[3],
        "helper_U_after_rho": helper.U_after[0],
        "helper_U_after_rho_u": helper.U_after[1],
        "helper_U_after_rho_E": helper.U_after[2],
        "helper_U_after_rho_xv": helper.U_after[3],
        "solver_U_after_rho": actual_after[0],
        "solver_U_after_rho_u": actual_after[1],
        "solver_U_after_rho_E": actual_after[2],
        "solver_U_after_rho_xv": actual_after[3],
        "reference_adapter_normalized_state_residual": normalized,
        "helper_normalized_balance_residual": helper.normalized_balance_residual,
        "budget_mass_residual_kg": budget["budget_mass_residual"],
        "budget_momentum_residual_kg_m_s": budget["budget_momentum_residual"],
        "budget_energy_residual_J": budget["budget_energy_residual"],
        "budget_vapor_residual_kg": budget["budget_vapor_mass_residual"],
        "right_flux_mass_kg_m2_s": solver.boundary_budget.last_right_flux[0],
        "right_flux_momentum_pa": solver.boundary_budget.last_right_flux[1],
        "right_flux_energy_W_m2": solver.boundary_budget.last_right_flux[2],
        "right_flux_vapor_kg_m2_s": solver.boundary_budget.last_right_flux[3],
        "formal_outcome": helper.formal_outcome,
    }


class _SyntheticPropertyFailure:
    version = "synthetic"

    def reconstruct(self, conserved: np.ndarray):
        raise RuntimeError("synthetic Hmass/Smass inversion failure")


class _SyntheticInvalidUpdateOverride:
    maximum_update_halvings = 12
    positivity_failure_outcome = adapter.BOUNDARY_UPDATE_POSITIVITY_FAILURE

    def limit_dt(self, **kwargs) -> float:
        return float(kwargs["candidate_dt_s"])

    def evaluate_flux(self, **kwargs) -> np.ndarray:
        return np.zeros(4, dtype=float)

    def validate_trial_state(self, **kwargs) -> None:
        raise ValueError("synthetic nonpositive internal energy")


def _evaluate_guards(
    *,
    contract: Mapping[str, Any],
    b1_contract: Mapping[str, Any],
) -> list[dict[str, Any]]:
    expected = {
        str(row["case_id"]): str(row["expected_outcome"])
        for row in contract["benchmark_cases"]
        if str(row["case_id"]).startswith("G-")
    }
    rows: list[dict[str, Any]] = []

    def add(case_id: str, outcome: str, message: str) -> None:
        rows.append(
            {
                "case_id": case_id,
                "expected_outcome": expected[case_id],
                "formal_outcome": outcome,
                "formal_message": message,
                "guard_triggered_before_flux": True,
                "guard_triggered_before_budget": True,
                "guard_triggered_before_state_mutation": True,
                "outcome_matches_contract": outcome == expected[case_id],
            }
        )

    for case_id in (
        "G-01_REVERSE_PRESSURE",
        "G-02_REVERSE_ADJACENT_VELOCITY",
        "G-03_NONFINITE_ADJACENT_STATE",
        "G-04_SINGLE_PHASE_SCOPE_FAILURE",
    ):
        provider = adapter.CoolPropAdjacentPropertyProvider()
        configuration = adapter.configuration_from_locked_case(contract, case_id)
        boundary = adapter.U3B2FvmDischargeAdapter(
            configuration,
            b2_contract=contract,
            b1_contract=b1_contract,
            property_provider=provider,
        )
        if case_id == "G-03_NONFINITE_ADJACENT_STATE":
            conserved = adapter.conserved_from_locked_family(
                contract, configuration.state_id, provider=provider
            )
            conserved[2] = math.nan
        else:
            conserved = _face_input(contract, case_id, provider)
        result = boundary.evaluate(conserved)
        add(case_id, result.formal_outcome, result.formal_message)

    configuration = adapter.configuration_from_locked_case(
        contract, "G-05_STAGNATION_RECONSTRUCTION_FAILURE"
    )
    boundary = adapter.U3B2FvmDischargeAdapter(
        configuration,
        b2_contract=contract,
        b1_contract=b1_contract,
        property_provider=_SyntheticPropertyFailure(),
    )
    finite_provider = adapter.CoolPropAdjacentPropertyProvider()
    conserved = adapter.conserved_from_locked_family(
        contract, configuration.state_id, provider=finite_provider
    )
    result = boundary.evaluate(conserved)
    add(
        "G-05_STAGNATION_RECONSTRUCTION_FAILURE",
        result.formal_outcome,
        result.formal_message,
    )

    configuration = adapter.configuration_from_locked_case(
        contract, "G-06_BOUNDARY_UPDATE_POSITIVITY_FAILURE"
    )
    provider = adapter.CoolPropAdjacentPropertyProvider()
    conserved = adapter.conserved_from_locked_family(
        contract, configuration.state_id, provider=provider
    )
    U = np.repeat(conserved[np.newaxis, :], 4, axis=0)
    grid = UniformGrid(
        PipeGeometry(
            length_m=float(contract["geometry"]["pipe_length_m"]),
            diameter_m=float(contract["geometry"]["pipe_diameter_m"]),
        ),
        n_cells=4,
    )
    solver = FvmSolver(
        grid=grid,
        eos=adapter.U3B2SinglePhaseCoolPropEOS(provider=provider),
        U=U,
        cfl=0.1,
        n_ghost=2,
        right_external_face_flux_override=_SyntheticInvalidUpdateOverride(),
        enable_boundary_budget=True,
        enable_phase_budget=False,
        enable_energy_budget=False,
        enable_interface_budget=False,
    )
    before = solver.U.copy()
    try:
        solver.step(solver.compute_dt())
    except ExternalFaceUpdateFailure as exc:
        unchanged = (
            np.array_equal(solver.U, before)
            and solver.t == 0.0
            and solver.step_count == 0
            and solver.boundary_budget is not None
            and np.array_equal(solver.boundary_budget.cumulative_left, np.zeros(4))
            and np.array_equal(solver.boundary_budget.cumulative_right, np.zeros(4))
        )
        outcome = exc.outcome if unchanged else "STATE_OR_BUDGET_MUTATED_ON_GUARD"
        add(
            "G-06_BOUNDARY_UPDATE_POSITIVITY_FAILURE",
            outcome,
            f"{exc}; state_and_budget_unchanged={unchanged}",
        )
    else:
        add(
            "G-06_BOUNDARY_UPDATE_POSITIVITY_FAILURE",
            "SYNTHETIC_GUARD_DID_NOT_FIRE",
            "Synthetic invalid update unexpectedly succeeded.",
        )

    initial = 1.0
    outward = 0.1
    correct_final = initial - outward
    wrong_sign_residual = correct_final - outward - initial
    if wrong_sign_residual != 0.0:
        add(
            "G-07_INVENTORY_ORIENTATION_MISMATCH",
            "INVENTORY_ORIENTATION_CONTRACT_MISMATCH",
            "Synthetic right-outward ledger sign mutation was rejected before acceptance.",
        )
    else:
        add(
            "G-07_INVENTORY_ORIENTATION_MISMATCH",
            "SYNTHETIC_ORIENTATION_GUARD_DID_NOT_FIRE",
            "Synthetic orientation mutation unexpectedly closed.",
        )

    return rows


def _build_checks(
    *,
    contract: Mapping[str, Any],
    face_results: Sequence[Mapping[str, Any]],
    comparisons: Sequence[Mapping[str, Any]],
    one_step: Mapping[str, Any],
    guards: Sequence[Mapping[str, Any]],
    adapter_source_path: Path,
) -> list[dict[str, Any]]:
    tol = contract["acceptance_tolerances"]
    checks: list[dict[str, Any]] = []

    def add(name: str, value: Any, target: Any, passed: bool) -> None:
        checks.append(
            {"check": name, "value": value, "target": target, "passed": passed}
        )

    source = adapter_source_path.read_text(encoding="utf-8")
    independent = "u3_b2_fvm_discharge_reference" not in source
    add("adapter_does_not_import_b2_reference", independent, True, independent)
    add(
        "face_formal_outcomes",
        all(bool(row["outcome_matches_reference"]) for row in face_results),
        True,
        all(bool(row["outcome_matches_reference"]) for row in face_results),
    )
    add(
        "reference_adapter_face_comparisons",
        sum(bool(row["comparison_passed"]) for row in comparisons),
        len(comparisons),
        all(bool(row["comparison_passed"]) for row in comparisons),
    )
    identities = []
    for row in face_results:
        if row["case_id"] in {
            "B2-01_CLOSED_LIQUID_WALL_IDENTITY",
            "B2-02_ZERO_DROP_LIQUID_WALL_IDENTITY",
            "B2-03_CLOSED_GAS_WALL_IDENTITY",
        }:
            identities.append(
                row["F_rho_kg_m2_s"] == 0.0
                and row["F_rho_u_pa"] == row["upstream_static_pressure_pa"]
                and row["F_rho_E_W_m2"] == 0.0
                and row["F_rho_xv_kg_m2_s"] == 0.0
            )
    add("exact_wall_identities", identities, [True, True, True], all(identities))
    add(
        "one_step_reference_adapter_normalized_state",
        one_step["reference_adapter_normalized_state_residual"],
        float(tol["one_step_normalized_state_absolute"]),
        float(one_step["reference_adapter_normalized_state_residual"])
        <= float(tol["one_step_normalized_state_absolute"]),
    )
    for key, tolerance_key in (
        ("budget_mass_residual_kg", "mass_inventory_absolute_kg"),
        ("budget_momentum_residual_kg_m_s", "momentum_inventory_absolute_kg_m_s"),
        ("budget_energy_residual_J", "energy_inventory_absolute_J"),
    ):
        value = abs(float(one_step[key]))
        target = float(tol[tolerance_key])
        add(key, value, target, value <= target)
    add(
        "budget_vapor_exact_zero",
        one_step["budget_vapor_residual_kg"],
        0.0,
        one_step["budget_vapor_residual_kg"] == 0.0,
    )
    add(
        "all_seven_guard_outcomes",
        sum(bool(row["outcome_matches_contract"]) for row in guards),
        7,
        len(guards) == 7 and all(bool(row["outcome_matches_contract"]) for row in guards),
    )
    return checks


def _plot_face_parity(
    path: Path,
    comparisons: Sequence[Mapping[str, Any]],
    *,
    source_git_sha: str,
    workflow_run_id: int,
) -> None:
    selected = [
        row for row in comparisons if row["measure"] != "F_rho_xv_kg_m2_s"
    ]
    fig, ax = plt.subplots(figsize=(8.5, 6.0))
    markers = {
        "F_rho_kg_m2_s": "o",
        "F_rho_u_pa": "s",
        "F_rho_E_W_m2": "^",
    }
    for measure, marker in markers.items():
        rows = [row for row in selected if row["measure"] == measure]
        ax.scatter(
            [abs(float(row["reference_value"])) for row in rows],
            [abs(float(row["adapter_value"])) for row in rows],
            marker=marker,
            label=measure,
        )
    values = [
        abs(float(row[key]))
        for row in selected
        for key in ("reference_value", "adapter_value")
        if abs(float(row[key])) > 0.0
    ]
    lower = min(values) * 0.8
    upper = max(values) * 1.2
    ax.plot([lower, upper], [lower, upper], linestyle="--", label="1:1")
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("Independent Reference magnitude")
    ax.set_ylabel("Adapter magnitude")
    ax.set_title("U3 B2 right-face flux parity")
    ax.grid(True, which="both", alpha=0.25)
    ax.legend()
    fig.tight_layout()
    description = (
        "B2_REFERENCE_ADAPTER_FACE_PARITY; "
        "model=U3 B2 production-side single-phase discharge-face Adapter; "
        "mapping=direct_external_face_flux_override; backend=CoolProp 8.0.0; "
        f"source={source_git_sha}; run={workflow_run_id}"
    )
    fig.savefig(path, dpi=170, metadata={"Description": description})
    plt.close(fig)


def _manifest(output_dir: Path) -> None:
    rows = []
    for path in sorted(output_dir.iterdir()):
        if path.name == "artifact_sha256.txt" or not path.is_file():
            continue
        rows.append(f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.name}")
    (output_dir / "artifact_sha256.txt").write_text(
        "\n".join(rows) + "\n", encoding="utf-8"
    )


def execute(
    *,
    contract_path: Path,
    extension_contract_path: Path,
    b1_contract_path: Path,
    reference_artifact_dir: Path,
    output_dir: Path,
    source_git_sha: str,
    reference_source_git_sha: str,
    reference_artifact_id: int | None,
    reference_artifact_zip_sha256: str,
    reference_resolution_mode: str,
) -> dict[str, Any]:
    contract = adapter.load_b2_contract(contract_path)
    b1_contract = adapter.load_b1_contract(b1_contract_path)
    extension = json.loads(extension_contract_path.read_text(encoding="utf-8"))
    reference_summary = json.loads(
        (reference_artifact_dir / "summary.json").read_text(encoding="utf-8")
    )
    if reference_summary["provenance"]["source_git_sha"] != reference_source_git_sha:
        raise ValueError("Reference artifact source SHA does not match the pinned SHA")
    reference_faces = _read_csv(reference_artifact_dir / "face_flux_decomposition.csv")
    reference_one_step_rows = _read_csv(
        reference_artifact_dir / "one_step_conservative_update_reference.csv"
    )
    if len(reference_faces) != 13 or len(reference_one_step_rows) != 1:
        raise ValueError("Reference artifact does not contain the locked face/one-step rows")

    face_rows, comparisons, face_results, inputs = _evaluate_faces(
        contract=contract,
        b1_contract=b1_contract,
        reference_rows=reference_faces,
    )
    del face_results, inputs
    one_step = _run_one_step(
        contract=contract,
        b1_contract=b1_contract,
        reference_row=reference_one_step_rows[0],
    )
    guards = _evaluate_guards(contract=contract, b1_contract=b1_contract)
    source_path = Path(adapter.__file__).resolve()
    checks = _build_checks(
        contract=contract,
        face_results=face_rows,
        comparisons=comparisons,
        one_step=one_step,
        guards=guards,
        adapter_source_path=source_path,
    )
    all_passed = all(bool(row["passed"]) for row in checks)
    provider = adapter.CoolPropAdjacentPropertyProvider()
    provenance = _provenance(
        source_git_sha=source_git_sha,
        reference_source_git_sha=reference_source_git_sha,
        reference_artifact_id=reference_artifact_id,
        reference_artifact_zip_sha256=reference_artifact_zip_sha256,
        reference_resolution_mode=reference_resolution_mode,
        property_backend_version=provider.version,
    )
    summary = {
        "schema_version": SCHEMA_VERSION,
        "scope": "verification_only_face_and_one_step",
        "face_case_count": len(face_rows),
        "reference_adapter_comparison_count": len(comparisons),
        "reference_adapter_comparison_pass_count": sum(
            bool(row["comparison_passed"]) for row in comparisons
        ),
        "guard_case_count": len(guards),
        "all_face_outcomes_match": all(
            bool(row["outcome_matches_reference"]) for row in face_rows
        ),
        "all_guard_outcomes_match": all(
            bool(row["outcome_matches_contract"]) for row in guards
        ),
        "all_reference_adapter_face_comparisons_passed": all(
            bool(row["comparison_passed"]) for row in comparisons
        ),
        "all_locked_adapter_checks_passed": all_passed,
        "one_step_reference_adapter_normalized_state_residual": one_step[
            "reference_adapter_normalized_state_residual"
        ],
        "maximum_face_absolute_residual": max(
            abs(float(row["residual"])) for row in comparisons
        ),
        "u3_b2_contract_locked": True,
        "u3_b2_reference_implemented": True,
        "u3_b2_fvm_adapter_implemented": True,
        "single_phase_fvm_discharge_mapping_verified": all_passed,
        "u3_b2_finite_pipe_execution_complete": False,
        "u3_b2_verification_benchmark_accepted": False,
        "single_phase_finite_pipe_coupling_verified": False,
        "physical_discharge_boundary_approved": False,
        "two_phase_critical_discharge_accuracy_approved": False,
        "integrated_blowdown_model_approved": False,
        "physical_validation": False,
        "design_use_acceptance": False,
        "production_hem_activation_approved": False,
        "adapter_imports_b2_reference_module": False,
        "production_rusanov_expression_changed": False,
        "provenance": provenance,
    }
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8"
    )
    (output_dir / "runtime_and_git_provenance.json").write_text(
        json.dumps(provenance, indent=2, sort_keys=True), encoding="utf-8"
    )
    (output_dir / "benchmark_contract.json").write_text(
        json.dumps(contract, indent=2, sort_keys=True), encoding="utf-8"
    )
    (output_dir / "event_provenance_contract.json").write_text(
        json.dumps(extension, indent=2, sort_keys=True), encoding="utf-8"
    )
    (output_dir / "b1_component_contract.json").write_text(
        json.dumps(b1_contract, indent=2, sort_keys=True), encoding="utf-8"
    )
    _write_csv(output_dir / FACE_RESULT_FILE, face_rows)
    _write_csv(output_dir / FACE_COMPARISON_FILE, comparisons)
    _write_csv(output_dir / ONE_STEP_FILE, [one_step])
    _write_csv(output_dir / GUARD_FILE, guards)
    _write_csv(output_dir / CHECK_FILE, checks)
    _plot_face_parity(
        output_dir / "reference_adapter_face_flux_parity.png",
        comparisons,
        source_git_sha=source_git_sha,
        workflow_run_id=int(os.environ.get("GITHUB_RUN_ID", "0")),
    )
    report = f"""# Stage 7 U3 B2 FVM Adapter — face / one-step authority\n\n## Purpose\n\nImplement the locked direct right external-face flux mapping independently of the U3 B2 Reference, then compare face outcomes, conservative transfers, Guards, and one actual FVM step against the pinned Reference evidence.\n\n## Authority\n\n- source SHA: `{source_git_sha}`\n- pinned Reference source SHA: `{reference_source_git_sha}`\n- Reference resolution: `{reference_resolution_mode}`\n- Reference Artifact ID: `{reference_artifact_id}`\n- Reference Artifact ZIP SHA256: `{reference_artifact_zip_sha256}`\n- property backend: CoolProp {provider.version}\n- workflow run: `{provenance['workflow_run_id']}`\n\n## Results\n\n- face cases: {len(face_rows)}\n- Reference–Adapter comparisons: {sum(bool(row['comparison_passed']) for row in comparisons)} / {len(comparisons)} PASS\n- Guards: {sum(bool(row['outcome_matches_contract']) for row in guards)} / {len(guards)} match\n- one-step normalized state residual: {one_step['reference_adapter_normalized_state_residual']:.17g}\n- locked checks: {sum(bool(row['passed']) for row in checks)} / {len(checks)} PASS\n\n## Supported claim\n\nThe production-side B2 Adapter implements the locked single-phase right-face mapping and one-step conservative update independently of the B2 Reference, within the pre-locked comparison tolerances.\n\n## Not supported\n\nThis increment does not establish finite-pipe coupling, mesh/CFL independence, two-phase critical discharge accuracy, physical Validation, design-use acceptance, integrated blowdown approval, or production HEM activation.\n"""
    (output_dir / "report.md").write_text(report, encoding="utf-8")
    _manifest(output_dir)
    if not all_passed:
        raise RuntimeError("one or more locked Adapter checks failed")
    return summary


def _parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--contract", type=Path, required=True)
    parser.add_argument("--extension-contract", type=Path, required=True)
    parser.add_argument("--b1-contract", type=Path, required=True)
    parser.add_argument("--reference-artifact-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--source-git-sha", required=True)
    parser.add_argument("--reference-source-git-sha", required=True)
    parser.add_argument("--reference-artifact-id", type=int)
    parser.add_argument("--reference-artifact-zip-sha256", default="")
    parser.add_argument(
        "--reference-resolution-mode",
        default="recomputed_from_pinned_source_sha",
    )
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = _parse_args(argv)
    execute(
        contract_path=args.contract,
        extension_contract_path=args.extension_contract,
        b1_contract_path=args.b1_contract,
        reference_artifact_dir=args.reference_artifact_dir,
        output_dir=args.output_dir,
        source_git_sha=args.source_git_sha,
        reference_source_git_sha=args.reference_source_git_sha,
        reference_artifact_id=args.reference_artifact_id,
        reference_artifact_zip_sha256=args.reference_artifact_zip_sha256,
        reference_resolution_mode=args.reference_resolution_mode,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
