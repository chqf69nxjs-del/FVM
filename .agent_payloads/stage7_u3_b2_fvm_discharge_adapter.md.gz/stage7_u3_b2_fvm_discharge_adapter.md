# Stage 7 U3 B2 FVM discharge-face Adapter

## 1. Purpose

This increment implements the locked U3 B2 single-phase discharge mapping on the production-side FVM path and verifies the face and one-step levels against the independent Reference.

The controlled order is:

```text
adjacent conserved state
→ static-state reconstruction
→ stagnation-state reconstruction
→ accepted U3 B1 single-phase discharge component
→ direct right external-face flux override
→ boundary budget
→ conservative update
```

This document does not close U3 B2. Finite-pipe execution, acoustic-event comparison, fixed mesh/CFL characterization, two-phase discharge, physical Validation, and design use remain outside this increment.

## 2. Locked authority

```text
Issue:
#135

B2 Contract PR / merge:
#136 / cffc32c257f58942e602614d69b6dad49bd1add8

B2 Reference PR / source / merge:
#138 / 0e2c8188961175b3c2cd56836296e713735bf8d9 / 4a70a831bb317ea70218e93801c469a12d7e046e

Reference authority run / artifact:
31203989733 / 9007750537

Reference Artifact ZIP SHA256:
1816e60920052391cb9ffde9242597b56571c9ed113c60ece8aa9f32cdb8c7cd
```

The pre-locked parent and event/provenance contracts remain unchanged.

## 3. Independence boundary

The Adapter may share the accepted B1 component because B1 is the immutable upstream discharge authority. It must not share B2-specific implementation with the Reference.

```text
Adapter imports U3 B2 Reference module:        false
shared B2 face-mapping helper:                 false
shared B2 one-step helper:                     false
shared B2 inventory helper:                    false
shared B2 acoustic helper:                     false
Reference result used as equation source:      false
Reference artifact used as comparison target:  true
```

The production-side property path uses CoolProp `AbstractState` with:

```text
Dmass / Umass → static p, T, h, s, c
h0 = h + u²/2
s0 = s
Hmass / Smass → stagnation p0, T0
```

The independent Reference retains its separate implementation path.

## 4. Direct external-face mapping

The discharge is not represented by a synthesized Euler ghost state. The right numerical face is replaced directly after the baseline Rusanov flux and internal-interface overrides.

```text
ghost-state Rusanov
→ internal-interface overrides
→ U3 B2 right external-face override
→ trial conservative update
→ accepted boundary budget
→ committed conservative update
```

The mapping is:

```text
A_open   = A_pipe * opening
A_closed = A_pipe - A_open

I_dot_total
  = m_dot_B1 * u_eff_B1
  + p_d * A_open
  + p_i * A_closed

F_right
  = [m_dot_B1 / A_pipe,
     I_dot_total / A_pipe,
     E_dot_B1 / A_pipe,
     0]
```

The pressure-force contribution is kept separate from the B1 stream momentum transfer.

## 5. Exact identities

The locked closed and static-coordinate zero-drop cases retain:

```text
F_right = [0, p_i, 0, 0]
```

For B2-02, the Adapter preserves the same narrowly scoped correction used by the accepted Reference:

- exact locked case identity;
- exact locked back pressure, opening, and discharge coefficient;
- exact-zero adjacent velocity;
- raw B1 outcome must already be successful;
- raw B1 outcome and message remain in provenance.

The following are not changed:

```text
B1 equation
B1 exact predicate
B2 contract
accepted tolerances
other case conditions
Guard disposition
```

## 6. Solver integration

`FvmSolver` receives an optional generic `right_external_face_flux_override` hook.

When the hook is `None`, the historical path remains unchanged. When active, the hook may:

1. limit the candidate time step;
2. provide the final right external-face flux;
3. validate a trial conservative state;
4. request a fixed maximum number of deterministic halvings.

The candidate time step is:

```text
dt = min(
    existing CFL dt,
    boundary mass-removal dt,
    boundary energy-removal dt,
    t_end - t
)
```

The mass and energy removal limits remain 10% of the adjacent-cell inventories per accepted step.

## 7. Deterministic positivity handling

The production solver trials the conservative update before mutating the boundary budget or solver state.

Accepted trial requirements are:

```text
finite conserved state
rho > 0
specific internal energy > 0
rho*xv = 0 exact
declared single-phase scope retained
```

If a trial fails, `dt` is halved deterministically, at most 12 times. Exhaustion returns:

```text
BOUNDARY_UPDATE_POSITIVITY_FAILURE
```

On exhaustion:

```text
solver state mutation:       none
solver time mutation:        none
step counter mutation:       none
boundary-budget mutation:    none
```

No tolerance or state condition is relaxed.

## 8. Face / one-step authority

The authoritative workflow regenerates the independent Reference from pinned source SHA `0e2c818...`, verifies its manifest, and passes the resulting artifact directory to the Adapter runner.

The Adapter runner evaluates:

```text
13 face/reference rows
4 conserved-flux measures per row
1 actual 32-cell / CFL 0.10 FVM step
7 atomic Guard outcomes
```

The comparison measures are:

```text
F_rho
F_rho_u
F_rho_E
F_rho_xv
```

Only the pre-locked absolute/relative tolerances are used.

## 9. Evidence package

The face/one-step increment produces:

```text
summary.json
runtime_and_git_provenance.json
benchmark_contract.json
event_provenance_contract.json
b1_component_contract.json
adapter_face_results.csv
reference_adapter_comparison.csv
one_step_conservative_update_comparison.csv
guard_outcomes.csv
locked_checks.csv
reference_adapter_face_flux_parity.png
report.md
artifact_sha256.txt
dedicated_junit.xml
related_junit.xml
full_repository_junit.xml
```

The workflow records the exact Adapter source SHA, pinned Reference source SHA, Reference Artifact ID and ZIP SHA256, runtime versions, workflow run identity, and internal artifact SHA256 manifest.

## 10. Supported claim after authoritative merge

If the locked face comparisons, one-step state/budget checks, Guards, independence checks, and required CI all pass at the expected head, the merge can support:

```text
u3_b2_contract_locked = true
u3_b2_reference_implemented = true
u3_b2_fvm_adapter_implemented = true
single_phase_fvm_discharge_mapping_verified = true
```

This means only that the locked single-phase face mapping and one-step conservative coupling agree with the independent Reference within the pre-locked tolerances.

## 11. Explicitly unsupported claims

The following remain false after this increment:

```text
u3_b2_finite_pipe_execution_complete = false
u3_b2_verification_benchmark_accepted = false
single_phase_finite_pipe_coupling_verified = false
physical_discharge_boundary_approved = false
two_phase_critical_discharge_accuracy_approved = false
integrated_blowdown_model_approved = false
physical_validation = false
design_use_acceptance = false
production_hem_activation_approved = false
```

No mesh/CFL independence, physical accuracy, commercial-code agreement, experimental Validation, or design applicability is inferred from face/one-step parity.

## 12. Next controlled work

After formal face/one-step closeout:

```text
LIQUID_SMALL_DROP finite pipe
→ GAS_UNCHOKED finite pipe
→ GAS_CHOKED finite pipe
→ mass / energy inventory closure
→ momentum impulse closure
→ direct rarefaction arrival
→ rigid-wall reflected arrival
→ 16 / 32 / 64 cells
→ CFL 0.10 / 0.05 / 0.025
→ B2 closeout decision
```

The fixed matrix will characterize mesh/CFL behavior; it will not claim independence unless the locked evidence actually supports that claim.
